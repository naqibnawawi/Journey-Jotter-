import { Component, OnInit } from '@angular/core';
import { AngularFirestore} from '@angular/fire/compat/firestore';
import { LoadingController, ToastController} from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

  posts: any;

  constructor(
    private loadingCtrl: LoadingController,
    private toastCtrl: ToastController,
    private firestore: AngularFirestore 
  ) {}

  option = {
    slidesPerView: 1,
    centeredSlides: true,
    loop: true,
    spaceBetween: 5,
    autoplay: true,
  };
 

 ngOnInit() {}
ionViewWillEnter() {
this.getPosts();
}
async getPosts(){
//show loader
let loader = await this.loadingCtrl.create({
message: "Please wait..."
});
loader.present();
try {
this.firestore
.collection("products")
    .snapshotChanges()
.subscribe(data => {
this.posts = data.map(e => {
return {
id: e.payload.doc.id,
category: e.payload.doc.data()["category"],
description: e.payload.doc.data()["description"],
image: e.payload.doc.data()["image"],
price: e.payload.doc.data()["price"],
Rating: e.payload.doc.data()["Rating"],
title: e.payload.doc.data()["title"],
Location: e.payload.doc.data()["Location"],
};
});

loader.dismiss();
});

} catch(e){
this.showToast(e);
}
}
async deletePost(id: string){
//show loader
let loader = this.loadingCtrl.create({
message: "Please wait..."
});
(await loader).present();
await this.firestore.doc("notes/" + id).delete();
//dismiss loader
(await loader).dismiss();
}
showToast (message:string){
this.toastCtrl.create({
message: message,
duration: 3000
}).then(toastData => toastData.present());
}

}
