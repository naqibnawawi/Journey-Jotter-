import { Component, OnInit } from '@angular/core';
import { AngularFirestore} from '@angular/fire/compat/firestore';
import { LoadingController, NavController, ToastController } from '@ionic/angular';
import { Hotel } from '../models/hotel.mode';


@Component({
selector: 'app-adhotel',
templateUrl: './adhotel.page.html',
styleUrls: ['./adhotel.page.scss'],
})
export class AdhotelPage implements OnInit {
hotel = {} as Hotel;
constructor(
private toastCtrl: ToastController,
private loadingCtrl: LoadingController,
private navCtrl: NavController,
private firestore: AngularFirestore
) {}
ngOnInit() {}
async createPost(hotel: Hotel){
if(this.formValidation()) {
//show loader
let loader = this.loadingCtrl.create({
message: "Please wait..."
});
(await loader).present();
try{
await this.firestore.collection("hotel").add(hotel);
} catch(e){
this.showToast(e);
}
//dismiss loader
(await loader).dismiss();
//redirect to home page
this.navCtrl.navigateRoot("adhotel");
}
}
formValidation(){
  if(!this.hotel.name){
    this.showToast("Enter name");
    return false;
    }
    if(!this.hotel.star){
    this.showToast("Enter star");
    return false;
    }
    if(!this.hotel.location){
    this.showToast("Enter location");
    return false;
    }
    if(!this.hotel.id){
    this.showToast("Enter id");
    return false;
    }
    if(!this.hotel.pool){
      this.showToast("Enter pool");
      return false;
      }
    if(!this.hotel.wifi){
      this.showToast("Enter wifi");
      return false;
        }
    if(!this.hotel.smoke){
      this.showToast("Enter Smoking Area");
      return false;
          }
    if(!this.hotel.link){
      this.showToast("Enter link");
      return false;
      }
    if(!this.hotel.image){
      this.showToast("Enter image");
      return false;
      }
    if(!this.hotel.image1){
      this.showToast("Enter second image");
      return false;
      } 
    return true;
    }
    showToast (message:string){
    this.toastCtrl.create({
    message: message,
    duration: 3000
    })
    .then(toastData => toastData.present());
    }}