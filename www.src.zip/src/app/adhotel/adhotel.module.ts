import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdhotelPageRoutingModule } from './adhotel-routing.module';

import { AdhotelPage } from './adhotel.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdhotelPageRoutingModule
  ],
  declarations: [AdhotelPage]
})
export class AdhotelPageModule {}
