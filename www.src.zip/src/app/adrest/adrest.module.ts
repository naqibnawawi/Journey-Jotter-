import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdrestPageRoutingModule } from './adrest-routing.module';

import { AdrestPage } from './adrest.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AdrestPageRoutingModule
  ],
  declarations: [AdrestPage]
})
export class AdrestPageModule {}
