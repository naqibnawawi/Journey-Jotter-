import { Component, OnInit } from '@angular/core';
import { AngularFirestore} from '@angular/fire/compat/firestore';
import { LoadingController, NavController, ToastController } from '@ionic/angular';
import { Rest } from '../models/rest.mode ';


@Component({
selector: 'app-adrest',
templateUrl: './adrest.page.html',
styleUrls: ['./adrest.page.scss'],
})
export class AdrestPage implements OnInit {
rest = {} as Rest;
constructor(
private toastCtrl: ToastController,
private loadingCtrl: LoadingController,
private navCtrl: NavController,
private firestore: AngularFirestore
) {}
ngOnInit() {}
async createPost(rest: Rest){
if(this.formValidation()) {
//show loader
let loader = this.loadingCtrl.create({
message: "Please wait..."
});
(await loader).present();
try{
await this.firestore.collection("rests").add(rest);
} catch(e){
this.showToast(e);
}
//dismiss loader
(await loader).dismiss();
//redirect to home page
this.navCtrl.navigateRoot("adrest");
}
}
formValidation(){
  if(!this.rest.name){
    this.showToast("Enter name");
    return false;
    }
    if(!this.rest.star){
    this.showToast("Enter star");
    return false;
    }
    if(!this.rest.location){
    this.showToast("Enter location");
    return false;
    }
    if(!this.rest.id){
    this.showToast("Enter id");
    return false;
    }
    if(!this.rest.link){
      this.showToast("Enter link");
      return false;
      }
    if(!this.rest.image){
      this.showToast("Enter image");
      return false;
      }
    if(!this.rest.image1){
      this.showToast("Enter second image");
      return false;
      } 
    return true;
    }
    showToast (message:string){
    this.toastCtrl.create({
    message: message,
    duration: 3000
    })
    .then(toastData => toastData.present());
    }}