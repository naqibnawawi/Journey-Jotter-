import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdrestPage } from './adrest.page';

const routes: Routes = [
  {
    path: '',
    component: AdrestPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdrestPageRoutingModule {}
