export interface Post {
    id: string;
    category: string;
    description: string;
    image: string;
    price: number;
    Rating: String;
    title: string;
    Location: String;
    hname: String;
}