export interface Hotel {
    id: string;
    name: string;
    link: string;
    image:string;
    image1:string;
    location:string;
    star:string;
    smoke:string;
    wifi:string;
    pool:string;
    
}