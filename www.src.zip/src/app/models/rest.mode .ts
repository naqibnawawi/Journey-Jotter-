export interface Rest {
    id: string;
    name: string;
    link: string;
    image:string;
    image1:string;
    location:string;
    star:string;
    
}