import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
 
export interface Product {
  id: number;
  name: string;
  price: number;
  amount: number;
}
@Injectable({
  providedIn: 'root'
})
export class CartService {
  data: Product[] = [
    { id: 0, name: 'LEGOLAND Malaysia', price: 190.0, amount: 0 },
    { id: 1, name: 'ESCAPE PARK Penang', price: 148.0, amount: 0 },
    { id: 2, name: 'Bayview Hotel Georgetown Penang', price: 230.0, amount: 0 },
    { id: 3, name: 'Mercure Penang Beach', price: 170.0, amount: 0 },
    { id: 4, name: 'Beach Shack Chalet', price: 93.4, amount: 0 },
    { id: 5, name: 'Kumone living', price: 300.0, amount: 0 },
    { id: 5, name: 'MyVilla Langkawi Hotel', price: 100, amount: 0 },
    { id: 2, name: 'Pulau Langkawi', price: 5.0, amount: 0 },
    { id: 3, name: 'Lost World Of Tambun', price: 47.0, amount: 0 },
    { id: 4, name: 'Zoo Negara Malaysia', price: 45, amount: 0 },
    { id: 5, name: 'Pulau Tioman', price: 5.0, amount: 0 },
    { id: 5, name: 'Bricks Family Restaurant', price: 50.0, amount: 0 },
    { id: 5, name: 'Mcdonals', price: 20.0, amount: 0 },
    { id: 2, name: 'Burger Junction', price: 25.0, amount: 0 },
    { id: 3, name: 'KFC(Medini Mall)', price: 20.5, amount: 0 },
    { id: 4, name: 'Sunday Restaurant', price: 20.0, amount: 0 },
    { id: 5, name: 'Grilled Kitchen Restaurant Tambun', price: 50.0, amount: 0 }
    
  ];
 
  private cart = [];
  private cartItemCount = new BehaviorSubject(0);
 
  constructor() {}
 
  getProducts() {
    return this.data;
  }
 
  getCart() {
    return this.cart;
  }
 
  getCartItemCount() {
    return this.cartItemCount;
  }
 
  addProduct(product) {
    let added = false;
    for (let p of this.cart) {
      if (p.id === product.id) {
        p.amount += 1;
        added = true;
        break;
      }
    }
    if (!added) {
      product.amount = 1;
      this.cart.push(product);
    }
    this.cartItemCount.next(this.cartItemCount.value + 1);
  }
 
  decreaseProduct(product) {
    for (let [index, p] of this.cart.entries()) {
      if (p.id === product.id) {
        p.amount -= 1;
        if (p.amount == 0) {
          this.cart.splice(index, 1);
        }
      }
    }
    this.cartItemCount.next(this.cartItemCount.value - 1);
  }
 
  removeProduct(product) {
    for (let [index, p] of this.cart.entries()) {
      if (p.id === product.id) {
        this.cartItemCount.next(this.cartItemCount.value - p.amount);
        this.cart.splice(index, 1);
      }
    }
  }
}