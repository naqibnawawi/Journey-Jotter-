import { Component, OnInit } from '@angular/core';
import { AngularFirestore} from '@angular/fire/compat/firestore';
import { Post } from '../models/post.mode';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-place',
  templateUrl: './place.page.html',
  styleUrls: ['./place.page.scss'],
})
export class PlacePage implements OnInit {

  post = {} as Post;
  id: any;


  constructor(
    private actRoute: ActivatedRoute, 
    private afs:AngularFirestore) { 
      this.id = this.actRoute.snapshot.paramMap.get("id");
    }


    ngOnInit(){
      this.viewDetails(this.id);
    }


    async viewDetails(id:string){
      this.afs.doc("products/" + id).valueChanges().subscribe(data => {
        this.post.id = data["id"];
        this.post.Location = data["Location"];
        this.post.Rating = data["Rating"];
        this.post.description = data["description"],
        this.post.title = data["title"];
        this.post.category = data["category"];
        this.post.price = data["price"];
        this.post.image = data["image"];
        this.post.hname = data["hname"];
      });
      }
    

      

    }