export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyCHvojGlJghLyn6m_FmBphfE7bp_wr80gM",
    authDomain: "journeyjotter2.firebaseapp.com",
    databaseURL: "https://journeyjotter2-default-rtdb.firebaseio.com",
    projectId: "journeyjotter2",
    storageBucket: "journeyjotter2.appspot.com",
    messagingSenderId: "1061629752804",
    appId: "1:1061629752804:web:f4b6f13580762f1e3783f1",
    measurementId: "G-REJCXM4NRT"
  }
};