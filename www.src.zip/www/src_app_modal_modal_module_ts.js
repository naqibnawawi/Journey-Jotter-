"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_modal_modal_module_ts"],{

/***/ 9130:
/*!***********************************************!*\
  !*** ./src/app/modal/modal-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalPageRoutingModule": () => (/* binding */ ModalPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _modal_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modal.page */ 2751);




const routes = [
    {
        path: '',
        component: _modal_page__WEBPACK_IMPORTED_MODULE_0__.ModalPage
    }
];
let ModalPageRoutingModule = class ModalPageRoutingModule {
};
ModalPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], ModalPageRoutingModule);



/***/ }),

/***/ 2641:
/*!***************************************!*\
  !*** ./src/app/modal/modal.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalPageModule": () => (/* binding */ ModalPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _modal_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modal-routing.module */ 9130);
/* harmony import */ var _modal_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal.page */ 2751);







let ModalPageModule = class ModalPageModule {
};
ModalPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _modal_routing_module__WEBPACK_IMPORTED_MODULE_0__.ModalPageRoutingModule
        ],
        declarations: [_modal_page__WEBPACK_IMPORTED_MODULE_1__.ModalPage]
    })
], ModalPageModule);



/***/ }),

/***/ 2751:
/*!*************************************!*\
  !*** ./src/app/modal/modal.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ModalPage": () => (/* binding */ ModalPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _modal_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modal.page.html?ngResource */ 2057);
/* harmony import */ var _modal_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal.page.scss?ngResource */ 9963);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/data.service */ 2468);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 3819);






let ModalPage = class ModalPage {
    constructor(dataService, modalCtrl, toastCtrl) {
        this.dataService = dataService;
        this.modalCtrl = modalCtrl;
        this.toastCtrl = toastCtrl;
        this.note = null;
    }
    ngOnInit() {
        this.dataService.getNoteById(this.id).subscribe(res => {
            this.note = res;
        });
    }
    deleteNote() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.dataService.deleteNote(this.note);
            this.modalCtrl.dismiss();
        });
    }
    updateNote() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            yield this.dataService.updateNote(this.note);
            const toast = yield this.toastCtrl.create({
                message: 'Note updated!.',
                duration: 2000
            });
            toast.present();
        });
    }
};
ModalPage.ctorParameters = () => [
    { type: _services_data_service__WEBPACK_IMPORTED_MODULE_2__.DataService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ModalController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.ToastController }
];
ModalPage.propDecorators = {
    id: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.Input }]
};
ModalPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-modal',
        template: _modal_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_modal_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], ModalPage);



/***/ }),

/***/ 2468:
/*!******************************************!*\
  !*** ./src/app/services/data.service.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DataService": () => (/* binding */ DataService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/fire/firestore */ 6466);



let DataService = class DataService {
    constructor(firestore) {
        this.firestore = firestore;
    }
    getNotes() {
        const notesRef = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__.collection)(this.firestore, 'notes');
        return (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__.collectionData)(notesRef, { idField: 'id' });
    }
    getNoteById(id) {
        const noteDocRef = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__.doc)(this.firestore, `notes/${id}`);
        return (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__.docData)(noteDocRef, { idField: 'id' });
    }
    addNote(note) {
        const notesRef = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__.collection)(this.firestore, 'notes');
        return (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__.addDoc)(notesRef, note);
    }
    deleteNote(note) {
        const noteDocRef = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__.doc)(this.firestore, `notes/${note.id}`);
        return (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__.deleteDoc)(noteDocRef);
    }
    updateNote(note) {
        const noteDocRef = (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__.doc)(this.firestore, `notes/${note.id}`);
        return (0,_angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__.updateDoc)(noteDocRef, { title: note.title, text: note.text });
    }
};
DataService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_0__.Firestore }
];
DataService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], DataService);



/***/ }),

/***/ 1577:
/*!******************************************************************!*\
  !*** ./node_modules/@angular/fire/fesm2015/angular-fire-auth.js ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActionCodeOperation": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.ActionCodeOperation),
/* harmony export */   "ActionCodeURL": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.ActionCodeURL),
/* harmony export */   "AuthCredential": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.AuthCredential),
/* harmony export */   "AuthErrorCodes": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.AuthErrorCodes),
/* harmony export */   "EmailAuthCredential": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.EmailAuthCredential),
/* harmony export */   "EmailAuthProvider": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.EmailAuthProvider),
/* harmony export */   "FacebookAuthProvider": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.FacebookAuthProvider),
/* harmony export */   "FactorId": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.FactorId),
/* harmony export */   "GithubAuthProvider": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.GithubAuthProvider),
/* harmony export */   "GoogleAuthProvider": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.GoogleAuthProvider),
/* harmony export */   "OAuthCredential": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.OAuthCredential),
/* harmony export */   "OAuthProvider": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.OAuthProvider),
/* harmony export */   "OperationType": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.OperationType),
/* harmony export */   "PhoneAuthCredential": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.PhoneAuthCredential),
/* harmony export */   "PhoneAuthProvider": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.PhoneAuthProvider),
/* harmony export */   "PhoneMultiFactorGenerator": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.PhoneMultiFactorGenerator),
/* harmony export */   "ProviderId": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.ProviderId),
/* harmony export */   "RecaptchaVerifier": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.RecaptchaVerifier),
/* harmony export */   "SAMLAuthProvider": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.SAMLAuthProvider),
/* harmony export */   "SignInMethod": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.SignInMethod),
/* harmony export */   "TwitterAuthProvider": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.TwitterAuthProvider),
/* harmony export */   "browserLocalPersistence": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.browserLocalPersistence),
/* harmony export */   "browserPopupRedirectResolver": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.browserPopupRedirectResolver),
/* harmony export */   "browserSessionPersistence": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.browserSessionPersistence),
/* harmony export */   "debugErrorMap": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.debugErrorMap),
/* harmony export */   "inMemoryPersistence": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.inMemoryPersistence),
/* harmony export */   "indexedDBLocalPersistence": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.indexedDBLocalPersistence),
/* harmony export */   "prodErrorMap": () => (/* reexport safe */ firebase_auth__WEBPACK_IMPORTED_MODULE_1__.prodErrorMap),
/* harmony export */   "Auth": () => (/* binding */ Auth),
/* harmony export */   "AuthInstances": () => (/* binding */ AuthInstances),
/* harmony export */   "AuthModule": () => (/* binding */ AuthModule),
/* harmony export */   "applyActionCode": () => (/* binding */ applyActionCode),
/* harmony export */   "authInstance$": () => (/* binding */ authInstance$),
/* harmony export */   "authState": () => (/* binding */ authState),
/* harmony export */   "checkActionCode": () => (/* binding */ checkActionCode),
/* harmony export */   "confirmPasswordReset": () => (/* binding */ confirmPasswordReset),
/* harmony export */   "connectAuthEmulator": () => (/* binding */ connectAuthEmulator),
/* harmony export */   "createUserWithEmailAndPassword": () => (/* binding */ createUserWithEmailAndPassword),
/* harmony export */   "deleteUser": () => (/* binding */ deleteUser),
/* harmony export */   "fetchSignInMethodsForEmail": () => (/* binding */ fetchSignInMethodsForEmail),
/* harmony export */   "getAdditionalUserInfo": () => (/* binding */ getAdditionalUserInfo),
/* harmony export */   "getAuth": () => (/* binding */ getAuth),
/* harmony export */   "getIdToken": () => (/* binding */ getIdToken),
/* harmony export */   "getIdTokenResult": () => (/* binding */ getIdTokenResult),
/* harmony export */   "getMultiFactorResolver": () => (/* binding */ getMultiFactorResolver),
/* harmony export */   "getRedirectResult": () => (/* binding */ getRedirectResult),
/* harmony export */   "idToken": () => (/* binding */ idToken),
/* harmony export */   "initializeAuth": () => (/* binding */ initializeAuth),
/* harmony export */   "isSignInWithEmailLink": () => (/* binding */ isSignInWithEmailLink),
/* harmony export */   "linkWithCredential": () => (/* binding */ linkWithCredential),
/* harmony export */   "linkWithPhoneNumber": () => (/* binding */ linkWithPhoneNumber),
/* harmony export */   "linkWithPopup": () => (/* binding */ linkWithPopup),
/* harmony export */   "linkWithRedirect": () => (/* binding */ linkWithRedirect),
/* harmony export */   "multiFactor": () => (/* binding */ multiFactor),
/* harmony export */   "onAuthStateChanged": () => (/* binding */ onAuthStateChanged),
/* harmony export */   "onIdTokenChanged": () => (/* binding */ onIdTokenChanged),
/* harmony export */   "parseActionCodeURL": () => (/* binding */ parseActionCodeURL),
/* harmony export */   "provideAuth": () => (/* binding */ provideAuth),
/* harmony export */   "reauthenticateWithCredential": () => (/* binding */ reauthenticateWithCredential),
/* harmony export */   "reauthenticateWithPhoneNumber": () => (/* binding */ reauthenticateWithPhoneNumber),
/* harmony export */   "reauthenticateWithPopup": () => (/* binding */ reauthenticateWithPopup),
/* harmony export */   "reauthenticateWithRedirect": () => (/* binding */ reauthenticateWithRedirect),
/* harmony export */   "reload": () => (/* binding */ reload),
/* harmony export */   "sendEmailVerification": () => (/* binding */ sendEmailVerification),
/* harmony export */   "sendPasswordResetEmail": () => (/* binding */ sendPasswordResetEmail),
/* harmony export */   "sendSignInLinkToEmail": () => (/* binding */ sendSignInLinkToEmail),
/* harmony export */   "setPersistence": () => (/* binding */ setPersistence),
/* harmony export */   "signInAnonymously": () => (/* binding */ signInAnonymously),
/* harmony export */   "signInWithCredential": () => (/* binding */ signInWithCredential),
/* harmony export */   "signInWithCustomToken": () => (/* binding */ signInWithCustomToken),
/* harmony export */   "signInWithEmailAndPassword": () => (/* binding */ signInWithEmailAndPassword),
/* harmony export */   "signInWithEmailLink": () => (/* binding */ signInWithEmailLink),
/* harmony export */   "signInWithPhoneNumber": () => (/* binding */ signInWithPhoneNumber),
/* harmony export */   "signInWithPopup": () => (/* binding */ signInWithPopup),
/* harmony export */   "signInWithRedirect": () => (/* binding */ signInWithRedirect),
/* harmony export */   "signOut": () => (/* binding */ signOut),
/* harmony export */   "unlink": () => (/* binding */ unlink),
/* harmony export */   "updateCurrentUser": () => (/* binding */ updateCurrentUser),
/* harmony export */   "updateEmail": () => (/* binding */ updateEmail),
/* harmony export */   "updatePassword": () => (/* binding */ updatePassword),
/* harmony export */   "updatePhoneNumber": () => (/* binding */ updatePhoneNumber),
/* harmony export */   "updateProfile": () => (/* binding */ updateProfile),
/* harmony export */   "useDeviceLanguage": () => (/* binding */ useDeviceLanguage),
/* harmony export */   "user": () => (/* binding */ user),
/* harmony export */   "verifyBeforeUpdateEmail": () => (/* binding */ verifyBeforeUpdateEmail),
/* harmony export */   "verifyPasswordResetCode": () => (/* binding */ verifyPasswordResetCode)
/* harmony export */ });
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire */ 3413);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 5398);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 4383);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 1133);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 121);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_fire_app__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/fire/app */ 9150);
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/app */ 6369);
/* harmony import */ var _angular_fire_app_check__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/fire/app-check */ 5738);
/* harmony import */ var rxfire_auth__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! rxfire/auth */ 6890);
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase/auth */ 3628);











const AUTH_PROVIDER_NAME = 'auth';

class Auth {
  constructor(auth) {
    return auth;
  }

}

class AuthInstances {
  constructor() {
    return (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵgetAllInstancesOf"])(AUTH_PROVIDER_NAME);
  }

}

const authInstance$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.timer)(0, 300).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.concatMap)(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.from)((0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵgetAllInstancesOf"])(AUTH_PROVIDER_NAME))), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.distinct)());
const PROVIDED_AUTH_INSTANCES = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.InjectionToken('angularfire2.auth-instances');

function defaultAuthInstanceFactory(provided, defaultApp) {
  const defaultAuth = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵgetDefaultInstanceOf"])(AUTH_PROVIDER_NAME, provided, defaultApp);
  return defaultAuth && new Auth(defaultAuth);
}

function authInstanceFactory(fn) {
  return (zone, injector) => {
    const auth = zone.runOutsideAngular(() => fn(injector));
    return new Auth(auth);
  };
}

const AUTH_INSTANCES_PROVIDER = {
  provide: AuthInstances,
  deps: [[new _angular_core__WEBPACK_IMPORTED_MODULE_7__.Optional(), PROVIDED_AUTH_INSTANCES]]
};
const DEFAULT_AUTH_INSTANCE_PROVIDER = {
  provide: Auth,
  useFactory: defaultAuthInstanceFactory,
  deps: [[new _angular_core__WEBPACK_IMPORTED_MODULE_7__.Optional(), PROVIDED_AUTH_INSTANCES], _angular_fire_app__WEBPACK_IMPORTED_MODULE_8__.FirebaseApp]
};

class AuthModule {
  constructor() {
    (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.registerVersion)('angularfire', _angular_fire__WEBPACK_IMPORTED_MODULE_2__.VERSION.full, 'auth');
  }

}

AuthModule.ɵfac = function AuthModule_Factory(t) {
  return new (t || AuthModule)();
};

AuthModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({
  type: AuthModule
});
AuthModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({
  providers: [DEFAULT_AUTH_INSTANCE_PROVIDER, AUTH_INSTANCES_PROVIDER]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵsetClassMetadata"](AuthModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule,
    args: [{
      providers: [DEFAULT_AUTH_INSTANCE_PROVIDER, AUTH_INSTANCES_PROVIDER]
    }]
  }], function () {
    return [];
  }, null);
})();

function provideAuth(fn, ...deps) {
  return {
    ngModule: AuthModule,
    providers: [{
      provide: PROVIDED_AUTH_INSTANCES,
      useFactory: authInstanceFactory(fn),
      multi: true,
      deps: [_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgZone, _angular_core__WEBPACK_IMPORTED_MODULE_7__.Injector, _angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵAngularFireSchedulers"], _angular_fire_app__WEBPACK_IMPORTED_MODULE_8__.FirebaseApps, [new _angular_core__WEBPACK_IMPORTED_MODULE_7__.Optional(), _angular_fire_app_check__WEBPACK_IMPORTED_MODULE_9__.AppCheckInstances], ...deps]
    }]
  };
} // DO NOT MODIFY, this file is autogenerated by tools/build.ts


const authState = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_auth__WEBPACK_IMPORTED_MODULE_10__.authState, true);
const user = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_auth__WEBPACK_IMPORTED_MODULE_10__.user, true);
const idToken = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_auth__WEBPACK_IMPORTED_MODULE_10__.idToken, true); // DO NOT MODIFY, this file is autogenerated by tools/build.ts

const applyActionCode = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.applyActionCode, true);
const checkActionCode = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.checkActionCode, true);
const confirmPasswordReset = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.confirmPasswordReset, true);
const connectAuthEmulator = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.connectAuthEmulator, true);
const createUserWithEmailAndPassword = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.createUserWithEmailAndPassword, true);
const deleteUser = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.deleteUser, true);
const fetchSignInMethodsForEmail = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.fetchSignInMethodsForEmail, true);
const getAdditionalUserInfo = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.getAdditionalUserInfo, true);
const getAuth = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.getAuth, true);
const getIdToken = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.getIdToken, true);
const getIdTokenResult = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.getIdTokenResult, true);
const getMultiFactorResolver = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.getMultiFactorResolver, true);
const getRedirectResult = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.getRedirectResult, true);
const initializeAuth = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.initializeAuth, true);
const isSignInWithEmailLink = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.isSignInWithEmailLink, true);
const linkWithCredential = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.linkWithCredential, true);
const linkWithPhoneNumber = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.linkWithPhoneNumber, true);
const linkWithPopup = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.linkWithPopup, true);
const linkWithRedirect = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.linkWithRedirect, true);
const multiFactor = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.multiFactor, true);
const onAuthStateChanged = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.onAuthStateChanged, true);
const onIdTokenChanged = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.onIdTokenChanged, true);
const parseActionCodeURL = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.parseActionCodeURL, true);
const reauthenticateWithCredential = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.reauthenticateWithCredential, true);
const reauthenticateWithPhoneNumber = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.reauthenticateWithPhoneNumber, true);
const reauthenticateWithPopup = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.reauthenticateWithPopup, true);
const reauthenticateWithRedirect = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.reauthenticateWithRedirect, true);
const reload = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.reload, true);
const sendEmailVerification = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.sendEmailVerification, true);
const sendPasswordResetEmail = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.sendPasswordResetEmail, true);
const sendSignInLinkToEmail = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.sendSignInLinkToEmail, true);
const setPersistence = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.setPersistence, true);
const signInAnonymously = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.signInAnonymously, true);
const signInWithCredential = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.signInWithCredential, true);
const signInWithCustomToken = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.signInWithCustomToken, true);
const signInWithEmailAndPassword = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.signInWithEmailAndPassword, true);
const signInWithEmailLink = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.signInWithEmailLink, true);
const signInWithPhoneNumber = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.signInWithPhoneNumber, true);
const signInWithPopup = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.signInWithPopup, true);
const signInWithRedirect = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.signInWithRedirect, true);
const signOut = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.signOut, true);
const unlink = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.unlink, true);
const updateCurrentUser = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.updateCurrentUser, true);
const updateEmail = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.updateEmail, true);
const updatePassword = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.updatePassword, true);
const updatePhoneNumber = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.updatePhoneNumber, true);
const updateProfile = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.updateProfile, true);
const useDeviceLanguage = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.useDeviceLanguage, true);
const verifyBeforeUpdateEmail = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.verifyBeforeUpdateEmail, true);
const verifyPasswordResetCode = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_auth__WEBPACK_IMPORTED_MODULE_1__.verifyPasswordResetCode, true);
/**
 * Generated bundle index. Do not edit.
 */



/***/ }),

/***/ 6466:
/*!***********************************************************************!*\
  !*** ./node_modules/@angular/fire/fesm2015/angular-fire-firestore.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AbstractUserDataWriter": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.AbstractUserDataWriter),
/* harmony export */   "Bytes": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.Bytes),
/* harmony export */   "CACHE_SIZE_UNLIMITED": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.CACHE_SIZE_UNLIMITED),
/* harmony export */   "CollectionReference": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.CollectionReference),
/* harmony export */   "DocumentReference": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.DocumentReference),
/* harmony export */   "DocumentSnapshot": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.DocumentSnapshot),
/* harmony export */   "FieldPath": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.FieldPath),
/* harmony export */   "FieldValue": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.FieldValue),
/* harmony export */   "FirestoreError": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.FirestoreError),
/* harmony export */   "GeoPoint": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.GeoPoint),
/* harmony export */   "LoadBundleTask": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.LoadBundleTask),
/* harmony export */   "Query": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.Query),
/* harmony export */   "QueryConstraint": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.QueryConstraint),
/* harmony export */   "QueryDocumentSnapshot": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.QueryDocumentSnapshot),
/* harmony export */   "QuerySnapshot": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.QuerySnapshot),
/* harmony export */   "SnapshotMetadata": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.SnapshotMetadata),
/* harmony export */   "Timestamp": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.Timestamp),
/* harmony export */   "Transaction": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.Transaction),
/* harmony export */   "WriteBatch": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.WriteBatch),
/* harmony export */   "_DatabaseId": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__._DatabaseId),
/* harmony export */   "_DocumentKey": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__._DocumentKey),
/* harmony export */   "_EmptyAppCheckTokenProvider": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__._EmptyAppCheckTokenProvider),
/* harmony export */   "_EmptyAuthCredentialsProvider": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__._EmptyAuthCredentialsProvider),
/* harmony export */   "_FieldPath": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__._FieldPath),
/* harmony export */   "_cast": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__._cast),
/* harmony export */   "_debugAssert": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__._debugAssert),
/* harmony export */   "_isBase64Available": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__._isBase64Available),
/* harmony export */   "_logWarn": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__._logWarn),
/* harmony export */   "_setIndexConfiguration": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__._setIndexConfiguration),
/* harmony export */   "_validateIsNotUsedTogether": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__._validateIsNotUsedTogether),
/* harmony export */   "ensureFirestoreConfigured": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.ensureFirestoreConfigured),
/* harmony export */   "executeWrite": () => (/* reexport safe */ firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.executeWrite),
/* harmony export */   "Firestore": () => (/* binding */ Firestore),
/* harmony export */   "FirestoreInstances": () => (/* binding */ FirestoreInstances),
/* harmony export */   "FirestoreModule": () => (/* binding */ FirestoreModule),
/* harmony export */   "addDoc": () => (/* binding */ addDoc),
/* harmony export */   "arrayRemove": () => (/* binding */ arrayRemove),
/* harmony export */   "arrayUnion": () => (/* binding */ arrayUnion),
/* harmony export */   "auditTrail": () => (/* binding */ auditTrail),
/* harmony export */   "clearIndexedDbPersistence": () => (/* binding */ clearIndexedDbPersistence),
/* harmony export */   "collection": () => (/* binding */ collection),
/* harmony export */   "collectionChanges": () => (/* binding */ collectionChanges),
/* harmony export */   "collectionData": () => (/* binding */ collectionData),
/* harmony export */   "collectionGroup": () => (/* binding */ collectionGroup),
/* harmony export */   "collectionSnapshots": () => (/* binding */ collectionSnapshots),
/* harmony export */   "connectFirestoreEmulator": () => (/* binding */ connectFirestoreEmulator),
/* harmony export */   "deleteDoc": () => (/* binding */ deleteDoc),
/* harmony export */   "deleteField": () => (/* binding */ deleteField),
/* harmony export */   "disableNetwork": () => (/* binding */ disableNetwork),
/* harmony export */   "doc": () => (/* binding */ doc),
/* harmony export */   "docData": () => (/* binding */ docData),
/* harmony export */   "docSnapshots": () => (/* binding */ docSnapshots),
/* harmony export */   "documentId": () => (/* binding */ documentId),
/* harmony export */   "enableIndexedDbPersistence": () => (/* binding */ enableIndexedDbPersistence),
/* harmony export */   "enableMultiTabIndexedDbPersistence": () => (/* binding */ enableMultiTabIndexedDbPersistence),
/* harmony export */   "enableNetwork": () => (/* binding */ enableNetwork),
/* harmony export */   "endAt": () => (/* binding */ endAt),
/* harmony export */   "endBefore": () => (/* binding */ endBefore),
/* harmony export */   "firestoreInstance$": () => (/* binding */ firestoreInstance$),
/* harmony export */   "fromRef": () => (/* binding */ fromRef),
/* harmony export */   "getDoc": () => (/* binding */ getDoc),
/* harmony export */   "getDocFromCache": () => (/* binding */ getDocFromCache),
/* harmony export */   "getDocFromServer": () => (/* binding */ getDocFromServer),
/* harmony export */   "getDocs": () => (/* binding */ getDocs),
/* harmony export */   "getDocsFromCache": () => (/* binding */ getDocsFromCache),
/* harmony export */   "getDocsFromServer": () => (/* binding */ getDocsFromServer),
/* harmony export */   "getFirestore": () => (/* binding */ getFirestore),
/* harmony export */   "increment": () => (/* binding */ increment),
/* harmony export */   "initializeFirestore": () => (/* binding */ initializeFirestore),
/* harmony export */   "limit": () => (/* binding */ limit),
/* harmony export */   "limitToLast": () => (/* binding */ limitToLast),
/* harmony export */   "loadBundle": () => (/* binding */ loadBundle),
/* harmony export */   "namedQuery": () => (/* binding */ namedQuery),
/* harmony export */   "onSnapshot": () => (/* binding */ onSnapshot),
/* harmony export */   "onSnapshotsInSync": () => (/* binding */ onSnapshotsInSync),
/* harmony export */   "orderBy": () => (/* binding */ orderBy),
/* harmony export */   "provideFirestore": () => (/* binding */ provideFirestore),
/* harmony export */   "query": () => (/* binding */ query),
/* harmony export */   "queryEqual": () => (/* binding */ queryEqual),
/* harmony export */   "refEqual": () => (/* binding */ refEqual),
/* harmony export */   "runTransaction": () => (/* binding */ runTransaction),
/* harmony export */   "serverTimestamp": () => (/* binding */ serverTimestamp),
/* harmony export */   "setDoc": () => (/* binding */ setDoc),
/* harmony export */   "setLogLevel": () => (/* binding */ setLogLevel),
/* harmony export */   "snapToData": () => (/* binding */ snapToData),
/* harmony export */   "snapshotEqual": () => (/* binding */ snapshotEqual),
/* harmony export */   "sortedChanges": () => (/* binding */ sortedChanges),
/* harmony export */   "startAfter": () => (/* binding */ startAfter),
/* harmony export */   "startAt": () => (/* binding */ startAt),
/* harmony export */   "terminate": () => (/* binding */ terminate),
/* harmony export */   "updateDoc": () => (/* binding */ updateDoc),
/* harmony export */   "waitForPendingWrites": () => (/* binding */ waitForPendingWrites),
/* harmony export */   "where": () => (/* binding */ where),
/* harmony export */   "writeBatch": () => (/* binding */ writeBatch)
/* harmony export */ });
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire */ 3413);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 5398);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 4383);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 1133);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 121);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/fire/auth */ 1577);
/* harmony import */ var _angular_fire_app__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/fire/app */ 9150);
/* harmony import */ var firebase_app__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/app */ 6369);
/* harmony import */ var _angular_fire_app_check__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/fire/app-check */ 5738);
/* harmony import */ var rxfire_firestore__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! rxfire/firestore */ 2144);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase/firestore */ 1866);













class Firestore {
  constructor(firestore) {
    return firestore;
  }

}

const FIRESTORE_PROVIDER_NAME = 'firestore';

class FirestoreInstances {
  constructor() {
    return (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵgetAllInstancesOf"])(FIRESTORE_PROVIDER_NAME);
  }

}

const firestoreInstance$ = (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.timer)(0, 300).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.concatMap)(() => (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.from)((0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵgetAllInstancesOf"])(FIRESTORE_PROVIDER_NAME))), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.distinct)());
const PROVIDED_FIRESTORE_INSTANCES = new _angular_core__WEBPACK_IMPORTED_MODULE_7__.InjectionToken('angularfire2.firestore-instances');

function defaultFirestoreInstanceFactory(provided, defaultApp) {
  const defaultFirestore = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵgetDefaultInstanceOf"])(FIRESTORE_PROVIDER_NAME, provided, defaultApp);
  return defaultFirestore && new Firestore(defaultFirestore);
}

function firestoreInstanceFactory(fn) {
  return (zone, injector) => {
    const firestore = zone.runOutsideAngular(() => fn(injector));
    return new Firestore(firestore);
  };
}

const FIRESTORE_INSTANCES_PROVIDER = {
  provide: FirestoreInstances,
  deps: [[new _angular_core__WEBPACK_IMPORTED_MODULE_7__.Optional(), PROVIDED_FIRESTORE_INSTANCES]]
};
const DEFAULT_FIRESTORE_INSTANCE_PROVIDER = {
  provide: Firestore,
  useFactory: defaultFirestoreInstanceFactory,
  deps: [[new _angular_core__WEBPACK_IMPORTED_MODULE_7__.Optional(), PROVIDED_FIRESTORE_INSTANCES], _angular_fire_app__WEBPACK_IMPORTED_MODULE_8__.FirebaseApp]
};

class FirestoreModule {
  constructor() {
    (0,firebase_app__WEBPACK_IMPORTED_MODULE_0__.registerVersion)('angularfire', _angular_fire__WEBPACK_IMPORTED_MODULE_2__.VERSION.full, 'fst');
  }

}

FirestoreModule.ɵfac = function FirestoreModule_Factory(t) {
  return new (t || FirestoreModule)();
};

FirestoreModule.ɵmod = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineNgModule"]({
  type: FirestoreModule
});
FirestoreModule.ɵinj = /* @__PURE__ */_angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵɵdefineInjector"]({
  providers: [DEFAULT_FIRESTORE_INSTANCE_PROVIDER, FIRESTORE_INSTANCES_PROVIDER]
});

(function () {
  (typeof ngDevMode === "undefined" || ngDevMode) && _angular_core__WEBPACK_IMPORTED_MODULE_7__["ɵsetClassMetadata"](FirestoreModule, [{
    type: _angular_core__WEBPACK_IMPORTED_MODULE_7__.NgModule,
    args: [{
      providers: [DEFAULT_FIRESTORE_INSTANCE_PROVIDER, FIRESTORE_INSTANCES_PROVIDER]
    }]
  }], function () {
    return [];
  }, null);
})();

function provideFirestore(fn, ...deps) {
  return {
    ngModule: FirestoreModule,
    providers: [{
      provide: PROVIDED_FIRESTORE_INSTANCES,
      useFactory: firestoreInstanceFactory(fn),
      multi: true,
      deps: [_angular_core__WEBPACK_IMPORTED_MODULE_7__.NgZone, _angular_core__WEBPACK_IMPORTED_MODULE_7__.Injector, _angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵAngularFireSchedulers"], _angular_fire_app__WEBPACK_IMPORTED_MODULE_8__.FirebaseApps, // Firestore+Auth work better if Auth is loaded first
      [new _angular_core__WEBPACK_IMPORTED_MODULE_7__.Optional(), _angular_fire_auth__WEBPACK_IMPORTED_MODULE_9__.AuthInstances], [new _angular_core__WEBPACK_IMPORTED_MODULE_7__.Optional(), _angular_fire_app_check__WEBPACK_IMPORTED_MODULE_10__.AppCheckInstances], ...deps]
    }]
  };
} // DO NOT MODIFY, this file is autogenerated by tools/build.ts


const collectionChanges = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_firestore__WEBPACK_IMPORTED_MODULE_11__.collectionChanges, true);
const collectionSnapshots = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_firestore__WEBPACK_IMPORTED_MODULE_11__.collection, true);
const sortedChanges = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_firestore__WEBPACK_IMPORTED_MODULE_11__.sortedChanges, true);
const auditTrail = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_firestore__WEBPACK_IMPORTED_MODULE_11__.auditTrail, true);
const collectionData = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_firestore__WEBPACK_IMPORTED_MODULE_11__.collectionData, true);
const docSnapshots = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_firestore__WEBPACK_IMPORTED_MODULE_11__.doc, true);
const docData = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_firestore__WEBPACK_IMPORTED_MODULE_11__.docData, true);
const snapToData = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_firestore__WEBPACK_IMPORTED_MODULE_11__.snapToData, true);
const fromRef = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(rxfire_firestore__WEBPACK_IMPORTED_MODULE_11__.fromRef, true); // DO NOT MODIFY, this file is autogenerated by tools/build.ts

const addDoc = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.addDoc, true);
const arrayRemove = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.arrayRemove, true);
const arrayUnion = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.arrayUnion, true);
const clearIndexedDbPersistence = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.clearIndexedDbPersistence, true);
const collection = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.collection, true);
const collectionGroup = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.collectionGroup, true);
const connectFirestoreEmulator = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.connectFirestoreEmulator, true);
const deleteDoc = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.deleteDoc, true);
const deleteField = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.deleteField, true);
const disableNetwork = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.disableNetwork, true);
const doc = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.doc, true);
const documentId = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.documentId, true);
const enableIndexedDbPersistence = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.enableIndexedDbPersistence, true);
const enableMultiTabIndexedDbPersistence = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.enableMultiTabIndexedDbPersistence, true);
const enableNetwork = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.enableNetwork, true);
const endAt = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.endAt, true);
const endBefore = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.endBefore, true);
const getDoc = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getDoc, true);
const getDocFromCache = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getDocFromCache, true);
const getDocFromServer = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getDocFromServer, true);
const getDocs = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getDocs, true);
const getDocsFromCache = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getDocsFromCache, true);
const getDocsFromServer = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getDocsFromServer, true);
const getFirestore = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.getFirestore, true);
const increment = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.increment, true);
const initializeFirestore = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.initializeFirestore, true);
const limit = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.limit, true);
const limitToLast = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.limitToLast, true);
const loadBundle = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.loadBundle, true);
const namedQuery = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.namedQuery, true);
const onSnapshot = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.onSnapshot, true);
const onSnapshotsInSync = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.onSnapshotsInSync, true);
const orderBy = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.orderBy, true);
const query = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.query, true);
const queryEqual = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.queryEqual, true);
const refEqual = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.refEqual, true);
const runTransaction = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.runTransaction, true);
const serverTimestamp = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.serverTimestamp, true);
const setDoc = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.setDoc, true);
const setLogLevel = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.setLogLevel, true);
const snapshotEqual = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.snapshotEqual, true);
const startAfter = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.startAfter, true);
const startAt = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.startAt, true);
const terminate = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.terminate, true);
const updateDoc = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.updateDoc, true);
const waitForPendingWrites = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.waitForPendingWrites, true);
const where = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.where, true);
const writeBatch = (0,_angular_fire__WEBPACK_IMPORTED_MODULE_2__["ɵzoneWrap"])(firebase_firestore__WEBPACK_IMPORTED_MODULE_1__.writeBatch, true);
/**
 * Generated bundle index. Do not edit.
 */



/***/ }),

/***/ 931:
/*!***********************************************************!*\
  !*** ./node_modules/@firebase/auth/dist/esm2017/index.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActionCodeOperation": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.A),
/* harmony export */   "ActionCodeURL": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.ac),
/* harmony export */   "AuthCredential": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.G),
/* harmony export */   "AuthErrorCodes": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.C),
/* harmony export */   "EmailAuthCredential": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.H),
/* harmony export */   "EmailAuthProvider": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.L),
/* harmony export */   "FacebookAuthProvider": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.M),
/* harmony export */   "FactorId": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.F),
/* harmony export */   "GithubAuthProvider": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.Q),
/* harmony export */   "GoogleAuthProvider": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.N),
/* harmony export */   "OAuthCredential": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.I),
/* harmony export */   "OAuthProvider": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.T),
/* harmony export */   "OperationType": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.O),
/* harmony export */   "PhoneAuthCredential": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.J),
/* harmony export */   "PhoneAuthProvider": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.P),
/* harmony export */   "PhoneMultiFactorGenerator": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.m),
/* harmony export */   "ProviderId": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.o),
/* harmony export */   "RecaptchaVerifier": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.R),
/* harmony export */   "SAMLAuthProvider": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.U),
/* harmony export */   "SignInMethod": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.S),
/* harmony export */   "TwitterAuthProvider": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.V),
/* harmony export */   "applyActionCode": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.a1),
/* harmony export */   "browserLocalPersistence": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.b),
/* harmony export */   "browserPopupRedirectResolver": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.k),
/* harmony export */   "browserSessionPersistence": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.a),
/* harmony export */   "checkActionCode": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.a2),
/* harmony export */   "confirmPasswordReset": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.a0),
/* harmony export */   "connectAuthEmulator": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.E),
/* harmony export */   "createUserWithEmailAndPassword": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.a4),
/* harmony export */   "debugErrorMap": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.z),
/* harmony export */   "deleteUser": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.y),
/* harmony export */   "fetchSignInMethodsForEmail": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.a9),
/* harmony export */   "getAdditionalUserInfo": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.ak),
/* harmony export */   "getAuth": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.n),
/* harmony export */   "getIdToken": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.ah),
/* harmony export */   "getIdTokenResult": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.ai),
/* harmony export */   "getMultiFactorResolver": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.am),
/* harmony export */   "getRedirectResult": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.j),
/* harmony export */   "inMemoryPersistence": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.K),
/* harmony export */   "indexedDBLocalPersistence": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.i),
/* harmony export */   "initializeAuth": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.D),
/* harmony export */   "isSignInWithEmailLink": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.a7),
/* harmony export */   "linkWithCredential": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.Y),
/* harmony export */   "linkWithPhoneNumber": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.l),
/* harmony export */   "linkWithPopup": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.d),
/* harmony export */   "linkWithRedirect": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.g),
/* harmony export */   "multiFactor": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.an),
/* harmony export */   "onAuthStateChanged": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.t),
/* harmony export */   "onIdTokenChanged": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.q),
/* harmony export */   "parseActionCodeURL": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.ad),
/* harmony export */   "prodErrorMap": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.B),
/* harmony export */   "reauthenticateWithCredential": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "reauthenticateWithPhoneNumber": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.r),
/* harmony export */   "reauthenticateWithPopup": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.e),
/* harmony export */   "reauthenticateWithRedirect": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.h),
/* harmony export */   "reload": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.al),
/* harmony export */   "sendEmailVerification": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.aa),
/* harmony export */   "sendPasswordResetEmail": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.$),
/* harmony export */   "sendSignInLinkToEmail": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.a6),
/* harmony export */   "setPersistence": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.p),
/* harmony export */   "signInAnonymously": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.W),
/* harmony export */   "signInWithCredential": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.X),
/* harmony export */   "signInWithCustomToken": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__._),
/* harmony export */   "signInWithEmailAndPassword": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.a5),
/* harmony export */   "signInWithEmailLink": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.a8),
/* harmony export */   "signInWithPhoneNumber": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.s),
/* harmony export */   "signInWithPopup": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.c),
/* harmony export */   "signInWithRedirect": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.f),
/* harmony export */   "signOut": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.x),
/* harmony export */   "unlink": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.aj),
/* harmony export */   "updateCurrentUser": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.w),
/* harmony export */   "updateEmail": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.af),
/* harmony export */   "updatePassword": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.ag),
/* harmony export */   "updatePhoneNumber": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.u),
/* harmony export */   "updateProfile": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.ae),
/* harmony export */   "useDeviceLanguage": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.v),
/* harmony export */   "verifyBeforeUpdateEmail": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.ab),
/* harmony export */   "verifyPasswordResetCode": () => (/* reexport safe */ _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__.a3)
/* harmony export */ });
/* harmony import */ var _index_585b6059_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index-585b6059.js */ 411);
/* harmony import */ var _firebase_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @firebase/util */ 7748);
/* harmony import */ var _firebase_app__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @firebase/app */ 8770);
/* harmony import */ var _firebase_logger__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @firebase/logger */ 8118);
/* harmony import */ var _firebase_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @firebase/component */ 4692);








/***/ }),

/***/ 3628:
/*!******************************************************!*\
  !*** ./node_modules/firebase/auth/dist/index.esm.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ActionCodeOperation": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.ActionCodeOperation),
/* harmony export */   "ActionCodeURL": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.ActionCodeURL),
/* harmony export */   "AuthCredential": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.AuthCredential),
/* harmony export */   "AuthErrorCodes": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.AuthErrorCodes),
/* harmony export */   "EmailAuthCredential": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.EmailAuthCredential),
/* harmony export */   "EmailAuthProvider": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.EmailAuthProvider),
/* harmony export */   "FacebookAuthProvider": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.FacebookAuthProvider),
/* harmony export */   "FactorId": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.FactorId),
/* harmony export */   "GithubAuthProvider": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.GithubAuthProvider),
/* harmony export */   "GoogleAuthProvider": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.GoogleAuthProvider),
/* harmony export */   "OAuthCredential": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.OAuthCredential),
/* harmony export */   "OAuthProvider": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.OAuthProvider),
/* harmony export */   "OperationType": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.OperationType),
/* harmony export */   "PhoneAuthCredential": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.PhoneAuthCredential),
/* harmony export */   "PhoneAuthProvider": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.PhoneAuthProvider),
/* harmony export */   "PhoneMultiFactorGenerator": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.PhoneMultiFactorGenerator),
/* harmony export */   "ProviderId": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.ProviderId),
/* harmony export */   "RecaptchaVerifier": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.RecaptchaVerifier),
/* harmony export */   "SAMLAuthProvider": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.SAMLAuthProvider),
/* harmony export */   "SignInMethod": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.SignInMethod),
/* harmony export */   "TwitterAuthProvider": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.TwitterAuthProvider),
/* harmony export */   "applyActionCode": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.applyActionCode),
/* harmony export */   "browserLocalPersistence": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.browserLocalPersistence),
/* harmony export */   "browserPopupRedirectResolver": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.browserPopupRedirectResolver),
/* harmony export */   "browserSessionPersistence": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.browserSessionPersistence),
/* harmony export */   "checkActionCode": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.checkActionCode),
/* harmony export */   "confirmPasswordReset": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.confirmPasswordReset),
/* harmony export */   "connectAuthEmulator": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.connectAuthEmulator),
/* harmony export */   "createUserWithEmailAndPassword": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.createUserWithEmailAndPassword),
/* harmony export */   "debugErrorMap": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.debugErrorMap),
/* harmony export */   "deleteUser": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.deleteUser),
/* harmony export */   "fetchSignInMethodsForEmail": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.fetchSignInMethodsForEmail),
/* harmony export */   "getAdditionalUserInfo": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.getAdditionalUserInfo),
/* harmony export */   "getAuth": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.getAuth),
/* harmony export */   "getIdToken": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.getIdToken),
/* harmony export */   "getIdTokenResult": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.getIdTokenResult),
/* harmony export */   "getMultiFactorResolver": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.getMultiFactorResolver),
/* harmony export */   "getRedirectResult": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.getRedirectResult),
/* harmony export */   "inMemoryPersistence": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.inMemoryPersistence),
/* harmony export */   "indexedDBLocalPersistence": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.indexedDBLocalPersistence),
/* harmony export */   "initializeAuth": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.initializeAuth),
/* harmony export */   "isSignInWithEmailLink": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.isSignInWithEmailLink),
/* harmony export */   "linkWithCredential": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.linkWithCredential),
/* harmony export */   "linkWithPhoneNumber": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.linkWithPhoneNumber),
/* harmony export */   "linkWithPopup": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.linkWithPopup),
/* harmony export */   "linkWithRedirect": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.linkWithRedirect),
/* harmony export */   "multiFactor": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.multiFactor),
/* harmony export */   "onAuthStateChanged": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.onAuthStateChanged),
/* harmony export */   "onIdTokenChanged": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.onIdTokenChanged),
/* harmony export */   "parseActionCodeURL": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.parseActionCodeURL),
/* harmony export */   "prodErrorMap": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.prodErrorMap),
/* harmony export */   "reauthenticateWithCredential": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.reauthenticateWithCredential),
/* harmony export */   "reauthenticateWithPhoneNumber": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.reauthenticateWithPhoneNumber),
/* harmony export */   "reauthenticateWithPopup": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.reauthenticateWithPopup),
/* harmony export */   "reauthenticateWithRedirect": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.reauthenticateWithRedirect),
/* harmony export */   "reload": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.reload),
/* harmony export */   "sendEmailVerification": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.sendEmailVerification),
/* harmony export */   "sendPasswordResetEmail": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.sendPasswordResetEmail),
/* harmony export */   "sendSignInLinkToEmail": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.sendSignInLinkToEmail),
/* harmony export */   "setPersistence": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.setPersistence),
/* harmony export */   "signInAnonymously": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInAnonymously),
/* harmony export */   "signInWithCredential": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInWithCredential),
/* harmony export */   "signInWithCustomToken": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInWithCustomToken),
/* harmony export */   "signInWithEmailAndPassword": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInWithEmailAndPassword),
/* harmony export */   "signInWithEmailLink": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInWithEmailLink),
/* harmony export */   "signInWithPhoneNumber": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInWithPhoneNumber),
/* harmony export */   "signInWithPopup": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInWithPopup),
/* harmony export */   "signInWithRedirect": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signInWithRedirect),
/* harmony export */   "signOut": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.signOut),
/* harmony export */   "unlink": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.unlink),
/* harmony export */   "updateCurrentUser": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.updateCurrentUser),
/* harmony export */   "updateEmail": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.updateEmail),
/* harmony export */   "updatePassword": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.updatePassword),
/* harmony export */   "updatePhoneNumber": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.updatePhoneNumber),
/* harmony export */   "updateProfile": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.updateProfile),
/* harmony export */   "useDeviceLanguage": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.useDeviceLanguage),
/* harmony export */   "verifyBeforeUpdateEmail": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.verifyBeforeUpdateEmail),
/* harmony export */   "verifyPasswordResetCode": () => (/* reexport safe */ _firebase_auth__WEBPACK_IMPORTED_MODULE_0__.verifyPasswordResetCode)
/* harmony export */ });
/* harmony import */ var _firebase_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @firebase/auth */ 931);



/***/ }),

/***/ 1866:
/*!***********************************************************!*\
  !*** ./node_modules/firebase/firestore/dist/index.esm.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AbstractUserDataWriter": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.AbstractUserDataWriter),
/* harmony export */   "Bytes": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.Bytes),
/* harmony export */   "CACHE_SIZE_UNLIMITED": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.CACHE_SIZE_UNLIMITED),
/* harmony export */   "CollectionReference": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.CollectionReference),
/* harmony export */   "DocumentReference": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.DocumentReference),
/* harmony export */   "DocumentSnapshot": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.DocumentSnapshot),
/* harmony export */   "FieldPath": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.FieldPath),
/* harmony export */   "FieldValue": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.FieldValue),
/* harmony export */   "Firestore": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.Firestore),
/* harmony export */   "FirestoreError": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.FirestoreError),
/* harmony export */   "GeoPoint": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.GeoPoint),
/* harmony export */   "LoadBundleTask": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.LoadBundleTask),
/* harmony export */   "Query": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.Query),
/* harmony export */   "QueryConstraint": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.QueryConstraint),
/* harmony export */   "QueryDocumentSnapshot": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.QueryDocumentSnapshot),
/* harmony export */   "QuerySnapshot": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.QuerySnapshot),
/* harmony export */   "SnapshotMetadata": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.SnapshotMetadata),
/* harmony export */   "Timestamp": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.Timestamp),
/* harmony export */   "Transaction": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.Transaction),
/* harmony export */   "WriteBatch": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.WriteBatch),
/* harmony export */   "_DatabaseId": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__._DatabaseId),
/* harmony export */   "_DocumentKey": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__._DocumentKey),
/* harmony export */   "_EmptyAppCheckTokenProvider": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__._EmptyAppCheckTokenProvider),
/* harmony export */   "_EmptyAuthCredentialsProvider": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__._EmptyAuthCredentialsProvider),
/* harmony export */   "_FieldPath": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__._FieldPath),
/* harmony export */   "_cast": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__._cast),
/* harmony export */   "_debugAssert": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__._debugAssert),
/* harmony export */   "_isBase64Available": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__._isBase64Available),
/* harmony export */   "_logWarn": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__._logWarn),
/* harmony export */   "_setIndexConfiguration": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__._setIndexConfiguration),
/* harmony export */   "_validateIsNotUsedTogether": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__._validateIsNotUsedTogether),
/* harmony export */   "addDoc": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.addDoc),
/* harmony export */   "arrayRemove": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.arrayRemove),
/* harmony export */   "arrayUnion": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.arrayUnion),
/* harmony export */   "clearIndexedDbPersistence": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.clearIndexedDbPersistence),
/* harmony export */   "collection": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.collection),
/* harmony export */   "collectionGroup": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.collectionGroup),
/* harmony export */   "connectFirestoreEmulator": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.connectFirestoreEmulator),
/* harmony export */   "deleteDoc": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.deleteDoc),
/* harmony export */   "deleteField": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.deleteField),
/* harmony export */   "disableNetwork": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.disableNetwork),
/* harmony export */   "doc": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.doc),
/* harmony export */   "documentId": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.documentId),
/* harmony export */   "enableIndexedDbPersistence": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.enableIndexedDbPersistence),
/* harmony export */   "enableMultiTabIndexedDbPersistence": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.enableMultiTabIndexedDbPersistence),
/* harmony export */   "enableNetwork": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.enableNetwork),
/* harmony export */   "endAt": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.endAt),
/* harmony export */   "endBefore": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.endBefore),
/* harmony export */   "ensureFirestoreConfigured": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.ensureFirestoreConfigured),
/* harmony export */   "executeWrite": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.executeWrite),
/* harmony export */   "getDoc": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.getDoc),
/* harmony export */   "getDocFromCache": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.getDocFromCache),
/* harmony export */   "getDocFromServer": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.getDocFromServer),
/* harmony export */   "getDocs": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.getDocs),
/* harmony export */   "getDocsFromCache": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.getDocsFromCache),
/* harmony export */   "getDocsFromServer": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.getDocsFromServer),
/* harmony export */   "getFirestore": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.getFirestore),
/* harmony export */   "increment": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.increment),
/* harmony export */   "initializeFirestore": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.initializeFirestore),
/* harmony export */   "limit": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.limit),
/* harmony export */   "limitToLast": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.limitToLast),
/* harmony export */   "loadBundle": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.loadBundle),
/* harmony export */   "namedQuery": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.namedQuery),
/* harmony export */   "onSnapshot": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.onSnapshot),
/* harmony export */   "onSnapshotsInSync": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.onSnapshotsInSync),
/* harmony export */   "orderBy": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.orderBy),
/* harmony export */   "query": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.query),
/* harmony export */   "queryEqual": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.queryEqual),
/* harmony export */   "refEqual": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.refEqual),
/* harmony export */   "runTransaction": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.runTransaction),
/* harmony export */   "serverTimestamp": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.serverTimestamp),
/* harmony export */   "setDoc": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.setDoc),
/* harmony export */   "setLogLevel": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.setLogLevel),
/* harmony export */   "snapshotEqual": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.snapshotEqual),
/* harmony export */   "startAfter": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.startAfter),
/* harmony export */   "startAt": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.startAt),
/* harmony export */   "terminate": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.terminate),
/* harmony export */   "updateDoc": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.updateDoc),
/* harmony export */   "waitForPendingWrites": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.waitForPendingWrites),
/* harmony export */   "where": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.where),
/* harmony export */   "writeBatch": () => (/* reexport safe */ _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.writeBatch)
/* harmony export */ });
/* harmony import */ var _firebase_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @firebase/firestore */ 7448);



/***/ }),

/***/ 6890:
/*!***********************************************!*\
  !*** ./node_modules/rxfire/auth/index.esm.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "authState": () => (/* binding */ authState),
/* harmony export */   "idToken": () => (/* binding */ idToken),
/* harmony export */   "user": () => (/* binding */ user)
/* harmony export */ });
/* harmony import */ var firebase_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/auth */ 3628);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 2378);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ 4383);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs */ 4139);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 9095);




/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Create an observable of authentication state. The observer is only
 * triggered on sign-in or sign-out.
 * @param auth firebase.auth.Auth
 */
function authState(auth) {
    return new rxjs__WEBPACK_IMPORTED_MODULE_1__.Observable(function (subscriber) {
        var unsubscribe = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_0__.onAuthStateChanged)(auth, subscriber.next.bind(subscriber), subscriber.error.bind(subscriber), subscriber.complete.bind(subscriber));
        return { unsubscribe: unsubscribe };
    });
}
/**
 * Create an observable of user state. The observer is triggered for sign-in,
 * sign-out, and token refresh events
 * @param auth firebase.auth.Auth
 */
function user(auth) {
    return new rxjs__WEBPACK_IMPORTED_MODULE_1__.Observable(function (subscriber) {
        var unsubscribe = (0,firebase_auth__WEBPACK_IMPORTED_MODULE_0__.onIdTokenChanged)(auth, subscriber.next.bind(subscriber), subscriber.error.bind(subscriber), subscriber.complete.bind(subscriber));
        return { unsubscribe: unsubscribe };
    });
}
/**
 * Create an observable of idToken state. The observer is triggered for sign-in,
 * sign-out, and token refresh events
 * @param auth firebase.auth.Auth
 */
function idToken(auth) {
    return user(auth).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.switchMap)(function (user) { return (user ? (0,rxjs__WEBPACK_IMPORTED_MODULE_3__.from)((0,firebase_auth__WEBPACK_IMPORTED_MODULE_0__.getIdToken)(user)) : (0,rxjs__WEBPACK_IMPORTED_MODULE_4__.of)(null)); }));
}




/***/ }),

/***/ 2144:
/*!****************************************************!*\
  !*** ./node_modules/rxfire/firestore/index.esm.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "auditTrail": () => (/* binding */ auditTrail),
/* harmony export */   "collection": () => (/* binding */ collection),
/* harmony export */   "collectionChanges": () => (/* binding */ collectionChanges),
/* harmony export */   "collectionData": () => (/* binding */ collectionData),
/* harmony export */   "doc": () => (/* binding */ doc),
/* harmony export */   "docData": () => (/* binding */ docData),
/* harmony export */   "fromRef": () => (/* binding */ fromRef),
/* harmony export */   "snapToData": () => (/* binding */ snapToData),
/* harmony export */   "sortedChanges": () => (/* binding */ sortedChanges)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 868);
/* harmony import */ var firebase_firestore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase/firestore */ 1866);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ 2378);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ 6800);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ 6942);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ 9151);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/operators */ 5722);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs/operators */ 9221);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rxjs/operators */ 2647);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ 3298);





/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var DEFAULT_OPTIONS = { includeMetadataChanges: false };
function fromRef(ref, options) {
    if (options === void 0) { options = DEFAULT_OPTIONS; }
    /* eslint-enable @typescript-eslint/no-explicit-any */
    return new rxjs__WEBPACK_IMPORTED_MODULE_1__.Observable(function (subscriber) {
        var unsubscribe = (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.onSnapshot)(ref, options, {
            next: subscriber.next.bind(subscriber),
            error: subscriber.error.bind(subscriber),
            complete: subscriber.complete.bind(subscriber),
        });
        return { unsubscribe: unsubscribe };
    });
}

/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function doc(ref) {
    return fromRef(ref, { includeMetadataChanges: true });
}
/**
 * Returns a stream of a document, mapped to its data payload and optionally the document ID
 * @param query
 */
function docData(ref, options) {
    if (options === void 0) { options = {}; }
    return doc(ref).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(function (snap) { return snapToData(snap, options); }));
}
function snapToData(snapshot, options) {
    if (options === void 0) { options = {}; }
    // TODO clean up the typings
    var data = snapshot.data();
    // match the behavior of the JS SDK when the snapshot doesn't exist
    // it's possible with data converters too that the user didn't return an object
    if (!snapshot.exists() || typeof data !== 'object' || data === null) {
        return data;
    }
    if (options.idField) {
        data[options.idField] = snapshot.id;
    }
    return data;
}

/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var ALL_EVENTS = ['added', 'modified', 'removed'];
/**
 * Create an operator that determines if a the stream of document changes
 * are specified by the event filter. If the document change type is not
 * in specified events array, it will not be emitted.
 */
var filterEvents = function (events) {
    return (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.filter)(function (changes) {
        var hasChange = false;
        for (var i = 0; i < changes.length; i++) {
            var change = changes[i];
            if (events && events.indexOf(change.type) >= 0) {
                hasChange = true;
                break;
            }
        }
        return hasChange;
    });
};
/**
 * Splice arguments on top of a sliced array, to break top-level ===
 * this is useful for change-detection
 */
function sliceAndSplice(original, start, deleteCount) {
    var args = [];
    for (var _i = 3; _i < arguments.length; _i++) {
        args[_i - 3] = arguments[_i];
    }
    var returnArray = original.slice();
    returnArray.splice.apply(returnArray, (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__spreadArray)([start, deleteCount], args));
    return returnArray;
}
/**
 * Creates a new sorted array from a new change.
 * @param combined
 * @param change
 */
function processIndividualChange(combined, change) {
    switch (change.type) {
        case 'added':
            if (combined[change.newIndex] &&
                (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.refEqual)(combined[change.newIndex].doc.ref, change.doc.ref)) ;
            else {
                return sliceAndSplice(combined, change.newIndex, 0, change);
            }
            break;
        case 'modified':
            if (combined[change.oldIndex] == null ||
                (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.refEqual)(combined[change.oldIndex].doc.ref, change.doc.ref)) {
                // When an item changes position we first remove it
                // and then add it's new position
                if (change.oldIndex !== change.newIndex) {
                    var copiedArray = combined.slice();
                    copiedArray.splice(change.oldIndex, 1);
                    copiedArray.splice(change.newIndex, 0, change);
                    return copiedArray;
                }
                else {
                    return sliceAndSplice(combined, change.newIndex, 1, change);
                }
            }
            break;
        case 'removed':
            if (combined[change.oldIndex] &&
                (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.refEqual)(combined[change.oldIndex].doc.ref, change.doc.ref)) {
                return sliceAndSplice(combined, change.oldIndex, 1);
            }
            break;
    }
    return combined;
}
/**
 * Combines the total result set from the current set of changes from an incoming set
 * of changes.
 * @param current
 * @param changes
 * @param events
 */
function processDocumentChanges(current, changes, events) {
    if (events === void 0) { events = ALL_EVENTS; }
    changes.forEach(function (change) {
        // skip unwanted change types
        if (events.indexOf(change.type) > -1) {
            current = processIndividualChange(current, change);
        }
    });
    return current;
}
/**
 * Create an operator that allows you to compare the current emission with
 * the prior, even on first emission (where prior is undefined).
 */
var windowwise = function () {
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.pipe)((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_6__.startWith)(undefined), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_7__.pairwise)());
};
/**
 * Given two snapshots does their metadata match?
 * @param a
 * @param b
 */
var metaDataEquals = function (a, b) { return JSON.stringify(a.metadata) === JSON.stringify(b.metadata); };
/**
 * Create an operator that filters out empty changes. We provide the
 * ability to filter on events, which means all changes can be filtered out.
 * This creates an empty array and would be incorrect to emit.
 */
var filterEmptyUnlessFirst = function () {
    return (0,rxjs__WEBPACK_IMPORTED_MODULE_5__.pipe)(windowwise(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_3__.filter)(function (_a) {
        var prior = _a[0], current = _a[1];
        return current.length > 0 || prior === undefined;
    }), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(function (_a) {
        _a[0]; var current = _a[1];
        return current;
    }));
};
/**
 * Return a stream of document changes on a query. These results are not in sort order but in
 * order of occurence.
 * @param query
 */
function collectionChanges(query, options) {
    if (options === void 0) { options = {}; }
    return fromRef(query, { includeMetadataChanges: true }).pipe(windowwise(), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(function (_a) {
        var priorSnapshot = _a[0], currentSnapshot = _a[1];
        var docChanges = currentSnapshot.docChanges();
        if (priorSnapshot && !metaDataEquals(priorSnapshot, currentSnapshot)) {
            // the metadata has changed, docChanges() doesn't return metadata events, so let's
            // do it ourselves by scanning over all the docs and seeing if the metadata has changed
            // since either this docChanges() emission or the prior snapshot
            currentSnapshot.docs.forEach(function (currentDocSnapshot, currentIndex) {
                var currentDocChange = docChanges.find(function (c) {
                    return (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.refEqual)(c.doc.ref, currentDocSnapshot.ref);
                });
                if (currentDocChange) {
                    // if the doc is in the current changes and the metadata hasn't changed this doc
                    if (metaDataEquals(currentDocChange.doc, currentDocSnapshot)) {
                        return;
                    }
                }
                else {
                    // if there is a prior doc and the metadata hasn't changed skip this doc
                    var priorDocSnapshot = priorSnapshot === null || priorSnapshot === void 0 ? void 0 : priorSnapshot.docs.find(function (d) {
                        return (0,firebase_firestore__WEBPACK_IMPORTED_MODULE_0__.refEqual)(d.ref, currentDocSnapshot.ref);
                    });
                    if (priorDocSnapshot &&
                        metaDataEquals(priorDocSnapshot, currentDocSnapshot)) {
                        return;
                    }
                }
                docChanges.push({
                    oldIndex: currentIndex,
                    newIndex: currentIndex,
                    type: 'modified',
                    doc: currentDocSnapshot
                });
            });
        }
        return docChanges;
    }), filterEvents(options.events || ALL_EVENTS), filterEmptyUnlessFirst());
}
/**
 * Return a stream of document snapshots on a query. These results are in sort order.
 * @param query
 */
function collection(query) {
    return fromRef(query, { includeMetadataChanges: true }).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(function (changes) { return changes.docs; }));
}
/**
 * Return a stream of document changes on a query. These results are in sort order.
 * @param query
 */
function sortedChanges(query, options) {
    if (options === void 0) { options = {}; }
    return collectionChanges(query, options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.scan)(function (current, changes) {
        return processDocumentChanges(current, changes, options.events);
    }, []), (0,rxjs_operators__WEBPACK_IMPORTED_MODULE_9__.distinctUntilChanged)());
}
/**
 * Create a stream of changes as they occur it time. This method is similar
 * to docChanges() but it collects each event in an array over time.
 */
function auditTrail(query, options) {
    if (options === void 0) { options = {}; }
    return collectionChanges(query, options).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_8__.scan)(function (current, action) { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__spreadArray)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__spreadArray)([], current), action); }, []));
}
/**
 * Returns a stream of documents mapped to their data payload, and optionally the document ID
 * @param query
 */
function collectionData(query, options) {
    if (options === void 0) { options = {}; }
    return collection(query).pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_2__.map)(function (arr) {
        return arr.map(function (snap) { return snapToData(snap, options); });
    }));
}




/***/ }),

/***/ 868:
/*!*************************************************************!*\
  !*** ./node_modules/rxfire/node_modules/tslib/tslib.es6.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__extends": () => (/* binding */ __extends),
/* harmony export */   "__assign": () => (/* binding */ __assign),
/* harmony export */   "__rest": () => (/* binding */ __rest),
/* harmony export */   "__decorate": () => (/* binding */ __decorate),
/* harmony export */   "__param": () => (/* binding */ __param),
/* harmony export */   "__metadata": () => (/* binding */ __metadata),
/* harmony export */   "__awaiter": () => (/* binding */ __awaiter),
/* harmony export */   "__generator": () => (/* binding */ __generator),
/* harmony export */   "__createBinding": () => (/* binding */ __createBinding),
/* harmony export */   "__exportStar": () => (/* binding */ __exportStar),
/* harmony export */   "__values": () => (/* binding */ __values),
/* harmony export */   "__read": () => (/* binding */ __read),
/* harmony export */   "__spread": () => (/* binding */ __spread),
/* harmony export */   "__spreadArrays": () => (/* binding */ __spreadArrays),
/* harmony export */   "__spreadArray": () => (/* binding */ __spreadArray),
/* harmony export */   "__await": () => (/* binding */ __await),
/* harmony export */   "__asyncGenerator": () => (/* binding */ __asyncGenerator),
/* harmony export */   "__asyncDelegator": () => (/* binding */ __asyncDelegator),
/* harmony export */   "__asyncValues": () => (/* binding */ __asyncValues),
/* harmony export */   "__makeTemplateObject": () => (/* binding */ __makeTemplateObject),
/* harmony export */   "__importStar": () => (/* binding */ __importStar),
/* harmony export */   "__importDefault": () => (/* binding */ __importDefault),
/* harmony export */   "__classPrivateFieldGet": () => (/* binding */ __classPrivateFieldGet),
/* harmony export */   "__classPrivateFieldSet": () => (/* binding */ __classPrivateFieldSet)
/* harmony export */ });
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    if (typeof b !== "function" && b !== null)
        throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

var __createBinding = Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});

function __exportStar(m, o) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

/** @deprecated */
function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

/** @deprecated */
function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
}

function __spreadArray(to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
}

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

var __setModuleDefault = Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, privateMap) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to get private field on non-instance");
    }
    return privateMap.get(receiver);
}

function __classPrivateFieldSet(receiver, privateMap, value) {
    if (!privateMap.has(receiver)) {
        throw new TypeError("attempted to set private field on non-instance");
    }
    privateMap.set(receiver, value);
    return value;
}


/***/ }),

/***/ 9963:
/*!**************************************************!*\
  !*** ./src/app/modal/modal.page.scss?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtb2RhbC5wYWdlLnNjc3MifQ== */";

/***/ }),

/***/ 2057:
/*!**************************************************!*\
  !*** ./src/app/modal/modal.page.html?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar color=\"secondary\">\n    <ion-title>Details</ion-title>\n  </ion-toolbar>\n</ion-header>\n \n<ion-content>\n  <div *ngIf=\"note\">\n    <ion-item>\n      <ion-label position=\"stacked\">Title</ion-label>\n      <ion-input [(ngModel)]=\"note.title\"></ion-input>\n    </ion-item>\n \n    <ion-item>\n      <ion-label position=\"stacked\">Note</ion-label>\n      <ion-textarea [(ngModel)]=\"note.text\" rows=\"8\"></ion-textarea>\n    </ion-item>\n  </div>\n \n  <ion-button expand=\"block\" color=\"success\" (click)=\"updateNote()\">\n    <ion-icon name=\"save\" slot=\"start\"></ion-icon>\n    Update\n  </ion-button>\n  <ion-button expand=\"block\" color=\"danger\" (click)=\"deleteNote()\">\n    <ion-icon name=\"trash\" slot=\"start\"></ion-icon>\n    Delete\n  </ion-button>\n \n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_modal_modal_module_ts.js.map