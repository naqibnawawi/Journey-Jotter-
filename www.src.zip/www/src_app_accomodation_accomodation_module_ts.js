"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_accomodation_accomodation_module_ts"],{

/***/ 6776:
/*!*************************************************************!*\
  !*** ./src/app/accomodation/accomodation-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccomodationPageRoutingModule": () => (/* binding */ AccomodationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _accomodation_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./accomodation.page */ 8368);




const routes = [
    {
        path: '',
        component: _accomodation_page__WEBPACK_IMPORTED_MODULE_0__.AccomodationPage
    }
];
let AccomodationPageRoutingModule = class AccomodationPageRoutingModule {
};
AccomodationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AccomodationPageRoutingModule);



/***/ }),

/***/ 3018:
/*!*****************************************************!*\
  !*** ./src/app/accomodation/accomodation.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccomodationPageModule": () => (/* binding */ AccomodationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _accomodation_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./accomodation-routing.module */ 6776);
/* harmony import */ var _accomodation_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./accomodation.page */ 8368);







let AccomodationPageModule = class AccomodationPageModule {
};
AccomodationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _accomodation_routing_module__WEBPACK_IMPORTED_MODULE_0__.AccomodationPageRoutingModule
        ],
        declarations: [_accomodation_page__WEBPACK_IMPORTED_MODULE_1__.AccomodationPage]
    })
], AccomodationPageModule);



/***/ }),

/***/ 8368:
/*!***************************************************!*\
  !*** ./src/app/accomodation/accomodation.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AccomodationPage": () => (/* binding */ AccomodationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _accomodation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./accomodation.page.html?ngResource */ 3422);
/* harmony import */ var _accomodation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./accomodation.page.scss?ngResource */ 1966);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_fire_compat_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/compat/firestore */ 2393);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);






let AccomodationPage = class AccomodationPage {
    constructor(loadingCtrl, toastCtrl, firestore) {
        this.loadingCtrl = loadingCtrl;
        this.toastCtrl = toastCtrl;
        this.firestore = firestore;
        this.option = {
            slidesPerView: 1,
            centeredSlides: true,
            loop: true,
            spaceBetween: 5,
            //autoplay: true,
        };
    }
    ngOnInit() { }
    ionViewWillEnter() {
        this.getPosts();
    }
    getPosts() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            //show loader
            let loader = yield this.loadingCtrl.create({
                message: "Please wait..."
            });
            loader.present();
            try {
                this.firestore
                    .collection("hotels")
                    .snapshotChanges()
                    .subscribe(data => {
                    this.hotels = data.map(e => {
                        return {
                            id: e.payload.doc.id,
                            image: e.payload.doc.data()["image"],
                            image1: e.payload.doc.data()["image1"],
                            link: e.payload.doc.data()["link"],
                            name: e.payload.doc.data()["name"],
                            location: e.payload.doc.data()["location"],
                        };
                    });
                    loader.dismiss();
                });
            }
            catch (e) {
                this.showToast(e);
            }
        });
    }
    deletePost(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            //show loader
            let loader = this.loadingCtrl.create({
                message: "Please wait..."
            });
            (yield loader).present();
            yield this.firestore.doc("notes/" + id).delete();
            //dismiss loader
            (yield loader).dismiss();
        });
    }
    showToast(message) {
        this.toastCtrl.create({
            message: message,
            duration: 3000
        }).then(toastData => toastData.present());
    }
};
AccomodationPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ToastController },
    { type: _angular_fire_compat_firestore__WEBPACK_IMPORTED_MODULE_4__.AngularFirestore }
];
AccomodationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-accomodation',
        template: _accomodation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_accomodation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AccomodationPage);



/***/ }),

/***/ 1966:
/*!****************************************************************!*\
  !*** ./src/app/accomodation/accomodation.page.scss?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = ".heading {\n  background-color: #3eb6ac;\n  width: 100%;\n  height: 150px;\n  border-bottom-left-radius: 55px;\n  border-bottom-right-radius: 55px;\n}\n.heading .heading {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  height: 50px;\n  align-items: center;\n  padding-top: 40px;\n}\n.heading .heading ion-label {\n  font-size: 50px;\n  margin-left: 20px;\n  color: #ffffff;\n  font-weight: bold;\n}\n.heading .heading ion-label span {\n  color: #000000;\n}\nion-slides {\n  width: 100x;\n  height: 100px;\n}\nion-slides ion-slide {\n  width: unset !important;\n  width: 50px;\n  height: 100px;\n  border-spacing: 20px;\n}\n#view ul {\n  padding: 0%;\n}\n#view ul h2 {\n  text-align: center;\n  font-size: medium;\n  color: #000000;\n}\n#view ul li {\n  position: relative;\n  overflow: hidden;\n  margin: 0;\n  background: #5ad0d8;\n  box-shadow: 0 3px 5px -2px rgba(0, 0, 0, 0.1);\n}\n#view ul li + li {\n  margin-top: 15px;\n}\n#view ul li i {\n  position: absolute;\n  transform: translate(-6px, 0);\n  margin-top: 28px;\n  right: 15px;\n}\n#view ul li i:before {\n  content: \"\";\n  position: absolute;\n  transition: all 0.3s;\n  background-color: #fff4f4;\n  width: 3px;\n  height: 9px;\n  transform: translate(-2px, 0) rotate(45deg);\n}\n#view ul li i:after {\n  transform: translate(2px, 0) rotate(-45deg);\n  transition: all 0.3s;\n  content: \"\";\n  position: absolute;\n  background-color: white;\n  width: 3px;\n  height: 9px;\n}\n#view ul li input[type=checkbox] {\n  position: absolute;\n  cursor: pointer;\n  width: 100%;\n  height: 100%;\n  z-index: 1;\n  opacity: 0;\n  touch-action: manipulation;\n}\n#view ul li input[type=checkbox]:checked ~ h2 {\n  color: black;\n}\n#view ul li input[type=checkbox]:checked ~ p {\n  max-height: 0;\n  transition: 0.3s;\n  opacity: 0;\n}\n#view ul li input[type=checkbox]:checked ~ i:before {\n  transform: translate(2px, 0) rotate(45deg);\n}\n#view ul li input[type=checkbox]:checked ~ i:after {\n  transform: translate(-2px, 0) rotate(-45deg);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFjY29tb2RhdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsK0JBQUE7RUFDQSxnQ0FBQTtBQUNKO0FBQ0k7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUFDTjtBQUFNO0VBRUUsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0FBQ1I7QUFBUTtFQUNFLGNBQUE7QUFFVjtBQUtBO0VBQ0ksV0FBQTtFQUNJLGFBQUE7QUFGUjtBQUlJO0VBQ0ksdUJBQUE7RUFDQSxXQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0FBRlI7QUFPSTtFQUVJLFdBQUE7QUFMUjtBQU1RO0VBQ0ksa0JBQUE7RUFDQSxpQkFBQTtFQUNJLGNBQUE7QUFKaEI7QUFPUTtFQUNJLGtCQUFBO0VBQ0EsZ0JBQUE7RUFFQSxTQUFBO0VBQ0EsbUJBQUE7RUFDQSw2Q0FBQTtBQU5aO0FBUWdCO0VBQ0ksZ0JBQUE7QUFOcEI7QUFTWTtFQUNJLGtCQUFBO0VBQ0EsNkJBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7QUFQaEI7QUFRZ0I7RUFDSSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxvQkFBQTtFQUNBLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSwyQ0FBQTtBQU5wQjtBQVFnQjtFQUNJLDJDQUFBO0VBQ0Esb0JBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FBTnBCO0FBU1k7RUFDSSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxVQUFBO0VBQ0EsMEJBQUE7QUFQaEI7QUFVd0I7RUFDSSxZQUFBO0FBUjVCO0FBVXdCO0VBQ0ksYUFBQTtFQUNBLGdCQUFBO0VBQ0EsVUFBQTtBQVI1QjtBQVc0QjtFQUNJLDBDQUFBO0FBVGhDO0FBVzRCO0VBQ0ksNENBQUE7QUFUaEMiLCJmaWxlIjoiYWNjb21vZGF0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5oZWFkaW5ne1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzNlYjZhYztcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxNTBweDtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDU1cHg7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czo1NXB4IDtcclxuICBcclxuICAgIC5oZWFkaW5ne1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgIHBhZGRpbmctdG9wOiA0MHB4O1xyXG4gICAgICBpb24tbGFiZWx7XHJcbiAgXHJcbiAgICAgICAgZm9udC1zaXplOiA1MHB4O1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgIHNwYW57XHJcbiAgICAgICAgICBjb2xvcjogIzAwMDAwMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuaW9uLXNsaWRlc3tcclxuICAgIHdpZHRoOiAxMDB4O1xyXG4gICAgICAgIGhlaWdodDogMTAwcHg7XHJcblxyXG4gICAgaW9uLXNsaWRlIHsgXHJcbiAgICAgICAgd2lkdGg6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgd2lkdGg6IDUwcHg7XHJcbiAgICAgICAgaGVpZ2h0OiAxMDBweDtcclxuICAgICAgICBib3JkZXItc3BhY2luZzogMjBweDtcclxuICAgICAgICB9XHJcbn1cclxuXHJcbiN2aWV3e1xyXG4gICAgdWx7XHJcbiAgICAgICAgXHJcbiAgICAgICAgcGFkZGluZzogMCU7XHJcbiAgICAgICAgaDJ7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgZm9udC1zaXplOiBtZWRpdW07XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogIzAwMDAwMDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxpe1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgICAgXHJcbiAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogcmdiKDkwLCAyMDgsIDIxNik7XHJcbiAgICAgICAgICAgIGJveC1zaGFkb3c6IDAgM3B4IDVweCAtMnB4IHJnYmEoMCwwLDAsMC4xKTtcclxuICAgICAgICAgICAgK3tcclxuICAgICAgICAgICAgICAgIGxpe1xyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6MTVweDtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpe1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTZweCwwKTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6IDI4cHg7XHJcbiAgICAgICAgICAgICAgICByaWdodDogMTVweDtcclxuICAgICAgICAgICAgICAgICY6YmVmb3Jle1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IGFsbCAwLjNzO1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUsIDI0NCwgMjQ0KTtcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogM3B4O1xyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogOXB4O1xyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC0ycHgsMCkgcm90YXRlKDQ1ZGVnKTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICY6YWZ0ZXJ7XHJcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoMnB4LDApIHJvdGF0ZSgtNDVkZWcpO1xyXG4gICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb246IGFsbCAwLjNzO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyNTUsIDI1NSwgMjU1KTtcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDogM3B4O1xyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogOXB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlucHV0W3R5cGU9XCJjaGVja2JveFwiXXtcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgei1pbmRleDogMTtcclxuICAgICAgICAgICAgICAgIG9wYWNpdHk6IDA7XHJcbiAgICAgICAgICAgICAgICB0b3VjaC1hY3Rpb246bWFuaXB1bGF0aW9uO1xyXG4gICAgICAgICAgICAgICAgJjpjaGVja2Vke1xyXG4gICAgICAgICAgICAgICAgICAgIH57XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGgye1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IGJsYWNrO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXgtaGVpZ2h0OiAwO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbjogMC4zcztcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgaXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICY6YmVmb3Jle1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKDJweCwwKSByb3RhdGUoNDVkZWcpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJjphZnRlcntcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtMnB4LDApIHJvdGF0ZSgtNDVkZWcpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */";

/***/ }),

/***/ 3422:
/*!****************************************************************!*\
  !*** ./src/app/accomodation/accomodation.page.html?ngResource ***!
  \****************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <div class=\"heading\">\n    <div class=\"heading\">\n      <div>\n        <ion-buttons slot=\"start\">\n          <ion-menu-button menuId=\"main-menu\" mode=\"ios\" defaultHref=\"/home\" color=\"dark\"></ion-menu-button>\n          <ion-label><br>Trav<span>elsy</span></ion-label>\n          \n        </ion-buttons>\n      </div>\n    </div>\n  </div>\n  \n  \n  \n      <br>\n      <ion-card  *ngFor=\"let hotel of hotels\">\n        <ion-grid>\n         <ion-row >\n          <ion-col>\n            <ion-slides>\n      <ion-slide>\n        <img [src]=\"hotel.image\" width=\"120px\">\n      </ion-slide>\n    </ion-slides>\n        </ion-col>\n        <ion-col>\n        <ion-item>\n          <h2>{{hotel.name}}</h2>\n        </ion-item> \n        </ion-col>\n        <div id=\"view\">\n          <ul>\n            <li>\n              <input type=\"checkbox\" checked>\n              <i></i>\n              <h2>View details</h2>\n              <p>\n                Location:{{hotel.location}}                                 \n              </p>\n\n            </li>\n          </ul>\n        </div>\n        <p class=\"greenText\"><a href=\"{{hotel.link}}\">Book Now</a></p>\n\n         </ion-row>\n        </ion-grid>\n      \n      </ion-card>\n  \n  \n  </ion-content>\n  ";

/***/ })

}]);
//# sourceMappingURL=src_app_accomodation_accomodation_module_ts.js.map