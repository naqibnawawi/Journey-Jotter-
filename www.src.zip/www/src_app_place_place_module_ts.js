"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_place_place_module_ts"],{

/***/ 27:
/*!***********************************************!*\
  !*** ./src/app/place/place-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlacePageRoutingModule": () => (/* binding */ PlacePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _place_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./place.page */ 9922);




const routes = [
    {
        path: '',
        component: _place_page__WEBPACK_IMPORTED_MODULE_0__.PlacePage
    }
];
let PlacePageRoutingModule = class PlacePageRoutingModule {
};
PlacePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], PlacePageRoutingModule);



/***/ }),

/***/ 6226:
/*!***************************************!*\
  !*** ./src/app/place/place.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlacePageModule": () => (/* binding */ PlacePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _place_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./place-routing.module */ 27);
/* harmony import */ var _place_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./place.page */ 9922);







let PlacePageModule = class PlacePageModule {
};
PlacePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _place_routing_module__WEBPACK_IMPORTED_MODULE_0__.PlacePageRoutingModule
        ],
        declarations: [_place_page__WEBPACK_IMPORTED_MODULE_1__.PlacePage]
    })
], PlacePageModule);



/***/ }),

/***/ 9922:
/*!*************************************!*\
  !*** ./src/app/place/place.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PlacePage": () => (/* binding */ PlacePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _place_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./place.page.html?ngResource */ 5419);
/* harmony import */ var _place_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./place.page.scss?ngResource */ 4369);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_fire_compat_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/compat/firestore */ 2393);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);






let PlacePage = class PlacePage {
    constructor(actRoute, afs) {
        this.actRoute = actRoute;
        this.afs = afs;
        this.post = {};
        this.id = this.actRoute.snapshot.paramMap.get("id");
    }
    ngOnInit() {
        this.viewDetails(this.id);
    }
    viewDetails(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            this.afs.doc("products/" + id).valueChanges().subscribe(data => {
                this.post.id = data["id"];
                this.post.Location = data["Location"];
                this.post.Rating = data["Rating"];
                this.post.description = data["description"],
                    this.post.title = data["title"];
                this.post.category = data["category"];
                this.post.price = data["price"];
                this.post.image = data["image"];
                this.post.hname = data["hname"];
            });
        });
    }
};
PlacePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute },
    { type: _angular_fire_compat_firestore__WEBPACK_IMPORTED_MODULE_4__.AngularFirestore }
];
PlacePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-place',
        template: _place_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_place_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], PlacePage);



/***/ }),

/***/ 4369:
/*!**************************************************!*\
  !*** ./src/app/place/place.page.scss?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = ".heading {\n  background-color: #3eb6ac;\n  width: 100%;\n  height: 150px;\n  border-bottom-left-radius: 55px;\n  border-bottom-right-radius: 55px;\n}\n.heading .heading {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  height: 50px;\n  align-items: center;\n  padding-top: 40px;\n}\n.heading .heading ion-label {\n  font-size: 50px;\n  margin-left: 20px;\n  color: #ffffff;\n  font-weight: bold;\n}\n.heading .heading ion-label span {\n  color: #000000;\n}\nion-content {\n  border-bottom-left-radius: 55px;\n  border-bottom-right-radius: 55px;\n  border-top-left-radius: 55px;\n  border-top-right-radius: 55px;\n  background-color: #f1eded;\n  --background: url(\"https://i.pinimg.com/originals/f5/af/38/f5af38611cd1bda1f68876a13bb6436e.jpg\") 0 0/100% 100% no-repeat;\n}\nion-content img {\n  border-radius: 50px;\n  overflow: hidden;\n}\nion-content p {\n  text-align: center;\n}\nion-content ion-card {\n  text-align: center;\n  border-bottom-right-radius: 55px;\n  border-bottom-left-radius: 55px;\n  border-top-left-radius: 55px;\n  border-top-right-radius: 55px;\n  background-color: #dd9878;\n  height: auto;\n}\nion-content ion-card h1 {\n  font-size: large;\n  color: #000000;\n}\nion-content ion-card h2 {\n  font-size: small;\n  color: #000000;\n}\nion-content ion-card h3 {\n  font-size: medium;\n  color: #000000;\n}\nion-content {\n  width: calc(100% + 35px);\n}\nion-content::part(scroll) {\n  padding-right: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBsYWNlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDRTtFQUNFLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSwrQkFBQTtFQUNBLGdDQUFBO0FBQUo7QUFFSTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBQUFOO0FBQ007RUFFRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUFBUjtBQUNRO0VBQ0UsY0FBQTtBQUNWO0FBT0E7RUFDSSwrQkFBQTtFQUNBLGdDQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtFQUNBLHlCQUFBO0VBQ0EseUhBQUE7QUFKSjtBQU1JO0VBQ0ksbUJBQUE7RUFDQSxnQkFBQTtBQUpSO0FBT0k7RUFDSSxrQkFBQTtBQUxSO0FBU1E7RUFDSSxrQkFBQTtFQUNBLGdDQUFBO0VBQ0EsK0JBQUE7RUFDQSw0QkFBQTtFQUNBLDZCQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0FBUFo7QUFTWTtFQUNJLGdCQUFBO0VBQ0EsY0FBQTtBQVBoQjtBQVVZO0VBQ0ksZ0JBQUE7RUFDQSxjQUFBO0FBUmhCO0FBV1k7RUFDSSxpQkFBQTtFQUNBLGNBQUE7QUFUaEI7QUFnQkU7RUFDRSx3QkFBQTtBQWJKO0FBZUU7RUFDRSxtQkFBQTtBQVpKIiwiZmlsZSI6InBsYWNlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG4gIC5oZWFkaW5ne1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzNlYjZhYztcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxNTBweDtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDU1cHg7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czo1NXB4IDtcclxuICBcclxuICAgIC5oZWFkaW5ne1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICBoZWlnaHQ6IDUwcHg7XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgIHBhZGRpbmctdG9wOiA0MHB4O1xyXG4gICAgICBpb24tbGFiZWx7XHJcbiAgXHJcbiAgICAgICAgZm9udC1zaXplOiA1MHB4O1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG4gICAgICAgIGNvbG9yOiAjZmZmZmZmO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgIHNwYW57XHJcbiAgICAgICAgICBjb2xvcjogIzAwMDAwMDtcclxuICAgICAgICB9XHJcbiAgICAgICAgXHJcbiAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuXHJcbmlvbi1jb250ZW50e1xyXG4gICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNTVweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOjU1cHggO1xyXG4gICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNTVweDtcclxuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOjU1cHggO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2YxZWRlZDtcclxuICAgIC0tYmFja2dyb3VuZDogdXJsKCdodHRwczovL2kucGluaW1nLmNvbS9vcmlnaW5hbHMvZjUvYWYvMzgvZjVhZjM4NjExY2QxYmRhMWY2ODg3NmExM2JiNjQzNmUuanBnJykgMCAwLzEwMCUgMTAwJSBuby1yZXBlYXQ7XHJcblxyXG4gICAgaW1nIHtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB9XHJcbiAgICBcclxuICAgIHB7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgfVxyXG5cclxuICAgIFxyXG4gICAgICAgIGlvbi1jYXJke1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6NTVweCA7XHJcbiAgICAgICAgICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6NTVweCA7XHJcbiAgICAgICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDU1cHg7XHJcbiAgICAgICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOjU1cHggO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGQ5ODc4O1xyXG4gICAgICAgICAgICBoZWlnaHQ6IGF1dG87XHJcblxyXG4gICAgICAgICAgICBoMXtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogbGFyZ2U7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogIzAwMDAwMDtcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgaDJ7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IHNtYWxsO1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICMwMDAwMDA7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIGgze1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiBtZWRpdW07XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogIzAwMDAwMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIFxyXG5cclxuICB9XHJcblxyXG4gIGlvbi1jb250ZW50IHtcclxuICAgIHdpZHRoOiBjYWxjKDEwMCUgKyAzNXB4KTtcclxuICB9XHJcbiAgaW9uLWNvbnRlbnQ6OnBhcnQoc2Nyb2xsKSB7XHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAxNXB4O1xyXG4gIH0iXX0= */";

/***/ }),

/***/ 5419:
/*!**************************************************!*\
  !*** ./src/app/place/place.page.html?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n<div class=\"heading\">\n  <div class=\"heading\">\n    <div>\n      <ion-buttons slot=\"start\">\n        <ion-menu-button menuId=\"main-menu\" mode=\"ios\" defaultHref=\"/home1\" color=\"dark\"></ion-menu-button>\n        <ion-label><br>Trav<span>elsy</span></ion-label>\n        \n      </ion-buttons>\n    </div>\n  </div>\n</div>\n\n\n\n    <br>\n    <img class=\"img\" [src]=\"post.image\"/>\n  <ion-card class=\"card-title\">\n   \n    <h1>{{post.title}}</h1>\n    <h2>\n    {{post.Location}}<br>\n    {{post.price | currency:'RM'}} (Entry fee)<br>\n    {{post.Rating}}</h2>\n    <h3>\n    {{post.description}}<br>\n    </h3>\n  </ion-card>\n\n  <ion-button [routerLink]=\"['/accomodation']\">Find a place to stay</ion-button>\n</ion-content>\n\n\n";

/***/ })

}]);
//# sourceMappingURL=src_app_place_place_module_ts.js.map