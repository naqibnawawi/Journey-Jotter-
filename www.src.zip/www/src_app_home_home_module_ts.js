"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_home_home_module_ts"],{

/***/ 2003:
/*!*********************************************!*\
  !*** ./src/app/home/home-routing.module.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageRoutingModule": () => (/* binding */ HomePageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 2816);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 2267);




const routes = [
    {
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage,
    }
];
let HomePageRoutingModule = class HomePageRoutingModule {
};
HomePageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
    })
], HomePageRoutingModule);



/***/ }),

/***/ 3467:
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePageModule": () => (/* binding */ HomePageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 6362);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 3819);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 587);
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page */ 2267);
/* harmony import */ var _home_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home-routing.module */ 2003);







let HomePageModule = class HomePageModule {
};
HomePageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _home_routing_module__WEBPACK_IMPORTED_MODULE_1__.HomePageRoutingModule
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_0__.HomePage]
    })
], HomePageModule);



/***/ }),

/***/ 2267:
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HomePage": () => (/* binding */ HomePage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4929);
/* harmony import */ var _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home.page.html?ngResource */ 3853);
/* harmony import */ var _home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./home.page.scss?ngResource */ 1020);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 3184);
/* harmony import */ var _angular_fire_compat_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/compat/firestore */ 2393);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 3819);






let HomePage = class HomePage {
    constructor(loadingCtrl, toastCtrl, firestore) {
        this.loadingCtrl = loadingCtrl;
        this.toastCtrl = toastCtrl;
        this.firestore = firestore;
        this.option = {
            slidesPerView: 1,
            centeredSlides: true,
            loop: true,
            spaceBetween: 5,
            //autoplay: true,
        };
    }
    ngOnInit() { }
    ionViewWillEnter() {
        this.getPosts();
    }
    getPosts() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            //show loader
            let loader = yield this.loadingCtrl.create({
                message: "Please wait..."
            });
            loader.present();
            try {
                this.firestore
                    .collection("products")
                    .snapshotChanges()
                    .subscribe(data => {
                    this.posts = data.map(e => {
                        return {
                            id: e.payload.doc.id,
                            category: e.payload.doc.data()["category"],
                            description: e.payload.doc.data()["description"],
                            image: e.payload.doc.data()["image"],
                            price: e.payload.doc.data()["price"],
                            Rating: e.payload.doc.data()["Rating"],
                            title: e.payload.doc.data()["title"],
                            Location: e.payload.doc.data()["Location"],
                        };
                    });
                    loader.dismiss();
                });
            }
            catch (e) {
                this.showToast(e);
            }
        });
    }
    deletePost(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__awaiter)(this, void 0, void 0, function* () {
            //show loader
            let loader = this.loadingCtrl.create({
                message: "Please wait..."
            });
            (yield loader).present();
            yield this.firestore.doc("notes/" + id).delete();
            //dismiss loader
            (yield loader).dismiss();
        });
    }
    showToast(message) {
        this.toastCtrl.create({
            message: message,
            duration: 3000
        }).then(toastData => toastData.present());
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.ToastController },
    { type: _angular_fire_compat_firestore__WEBPACK_IMPORTED_MODULE_4__.AngularFirestore }
];
HomePage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-home',
        template: _home_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_home_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], HomePage);



/***/ }),

/***/ 1020:
/*!************************************************!*\
  !*** ./src/app/home/home.page.scss?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ion-content {\n  width: 100%;\n  --background: url(\"https://play-lh.googleusercontent.com/04AEEuq-8XQ-e--fjapnnyDhtAM-a8J9zT7G6AkHvbJeE0hmjzYFOyhZx5-wDYHHIJY\") 0 0/100% 100% no-repeat;\n}\nion-content ion-slide ion-card {\n  border-bottom-right-radius: 55px;\n  border-bottom-left-radius: 55px;\n  border-top-left-radius: 55px;\n  border-top-right-radius: 55px;\n  background-color: #3eb6ac;\n}\nion-content ion-slide ion-card p {\n  color: #000000;\n}\nion-content h4 {\n  font-size: 17px;\n  color: #000000;\n}\nion-content h5 {\n  font-size: 15px;\n  color: #000000;\n}\nion-content .heading {\n  background-color: #3eb6ac;\n  width: 100%;\n  height: 150px;\n  border-bottom-left-radius: 55px;\n  border-bottom-right-radius: 55px;\n}\nion-content .heading .heading {\n  width: 100%;\n  display: flex;\n  justify-content: space-between;\n  height: 50px;\n  align-items: center;\n  padding-top: 40px;\n}\nion-content .heading .heading ion-label {\n  font-size: 50px;\n  margin-left: 20px;\n  color: #ffffff;\n  font-weight: bold;\n}\nion-content .heading .heading ion-label span {\n  color: #000000;\n}\nion-content .heading input {\n  border: none;\n  margin-top: 50px;\n  margin-left: 20px;\n  width: 90%;\n  height: 50px;\n  border-radius: 10px;\n  padding-left: 20px;\n}\nion-content .heading p {\n  text-align: center;\n}\nion-content .heading p a {\n  color: #000000;\n  text-decoration: underline;\n  padding-left: 15px;\n}\nion-content .heading ion-item {\n  --background: #00cab9;\n  color: #f7d9d9;\n  --border-style:none;\n}\nion-content .heading ion-item ion-icon {\n  font-size: 20px;\n}\nion-content .travel {\n  width: 100%;\n  height: 120px;\n  background-color: #ffffff;\n  margin-top: 20px;\n  display: flex;\n  justify-content: space-around;\n  column-gap: 20px;\n}\nion-content .travel .travel_names img {\n  width: 100%;\n  height: 25px;\n}\nion-content .travel .travel_names p {\n  text-align: left;\n  margin-top: 0px;\n  font-size: 12px;\n}\nion-content .travel .aboutContainer {\n  margin-top: -1rem;\n  padding: 1rem;\n}\nion-content .travel .aboutContainer ion-card-title {\n  font-size: 1.2rem;\n  margin-bottom: 0.5rem;\n}\nion-content .travel .lab {\n  color: #00cab9;\n  text-align: center;\n}\nion-content .travel .img {\n  width: 100%;\n  height: 25px;\n}\nion-content ion-row {\n  text-align: center;\n}\nion-content ion-col {\n  text-align: center;\n  padding: 4px;\n}\nion-content ion-col ion-icon {\n  zoom: 3;\n  padding: 10px;\n}\nion-content ion-col ion-icon:first-child {\n  zoom: 2.8;\n  padding: 2px;\n}\nion-content ion-col h6 {\n  font-size: 15px;\n  color: #000000;\n}\nion-content ion-col ion-card {\n  text-align: center;\n  width: 120px;\n  height: 120px;\n  background-color: #e47575;\n}\nion-content {\n  width: calc(100% + 35px);\n}\nion-content::part(scroll) {\n  padding-right: 15px;\n}\n.myColor {\n  background-color: blue;\n  text-align: center;\n  justify-content: center;\n  align-items: center;\n  color: white;\n}\nh1 {\n  font-size: large;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImhvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsV0FBQTtFQUNBLHNKQUFBO0FBQ0Y7QUFHSTtFQUNFLGdDQUFBO0VBQ0EsK0JBQUE7RUFDQSw0QkFBQTtFQUNBLDZCQUFBO0VBQ0EseUJBQUE7QUFETjtBQUdNO0VBQ0UsY0FBQTtBQURSO0FBT0E7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQUxGO0FBUUE7RUFDRSxlQUFBO0VBQ0EsY0FBQTtBQU5GO0FBUUE7RUFDRSx5QkFBQTtFQUNBLFdBQUE7RUFDQSxhQUFBO0VBQ0EsK0JBQUE7RUFDQSxnQ0FBQTtBQU5GO0FBUUU7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUFOSjtBQU9JO0VBRUUsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0FBTk47QUFPTTtFQUNFLGNBQUE7QUFMUjtBQVlJO0VBQ0UsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFWTjtBQVlJO0VBQ0Usa0JBQUE7QUFWTjtBQVdNO0VBQ0UsY0FBQTtFQUNBLDBCQUFBO0VBQ0Esa0JBQUE7QUFUUjtBQWNJO0VBQ0UscUJBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7QUFaTjtBQWFNO0VBQ0UsZUFBQTtBQVhSO0FBaUJFO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLDZCQUFBO0VBQ0EsZ0JBQUE7QUFmSjtBQWtCTTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBaEJSO0FBa0JNO0VBQ0UsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBQWhCUjtBQW1CSTtFQUVFLGlCQUFBO0VBQ0EsYUFBQTtBQWxCTjtBQW9CTTtFQUVFLGlCQUFBO0VBQ0EscUJBQUE7QUFuQlI7QUF1Qkk7RUFFRSxjQUFBO0VBQ0Esa0JBQUE7QUF0Qk47QUF3QkU7RUFDTSxXQUFBO0VBQ0EsWUFBQTtBQXRCUjtBQXlCQTtFQUNFLGtCQUFBO0FBdkJGO0FBMEJBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0FBeEJGO0FBeUJFO0VBQ0ksT0FBQTtFQUNBLGFBQUE7QUF2Qk47QUF3Qk07RUFDSSxTQUFBO0VBQ0EsWUFBQTtBQXRCVjtBQXlCRTtFQUNFLGVBQUE7RUFDQSxjQUFBO0FBdkJKO0FBeUJFO0VBQ0ksa0JBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHlCQUFBO0FBdkJOO0FBK0JBO0VBQ0Usd0JBQUE7QUE1QkY7QUE4QkE7RUFDRSxtQkFBQTtBQTNCRjtBQThCQTtFQUNFLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQTNCRjtBQThCQTtFQUNFLGdCQUFBO0FBM0JGIiwiZmlsZSI6ImhvbWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xuICB3aWR0aDogMTAwJTtcbiAgLS1iYWNrZ3JvdW5kOiB1cmwoJ2h0dHBzOi8vcGxheS1saC5nb29nbGV1c2VyY29udGVudC5jb20vMDRBRUV1cS04WFEtZS0tZmphcG5ueURodEFNLWE4Sjl6VDdHNkFrSHZiSmVFMGhtanpZRk95aFp4NS13RFlISElKWScpIDAgMC8xMDAlIDEwMCUgbm8tcmVwZWF0O1xuIFxuICBpb24tc2xpZGV7XG5cbiAgICBpb24tY2FyZHtcbiAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOjU1cHggO1xuICAgICAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czo1NXB4IDtcbiAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDU1cHg7XG4gICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czo1NXB4IDtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICMzZWI2YWM7XG5cbiAgICAgIHB7XG4gICAgICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgICAgfVxuICB9XG4gICAgXG4gIH1cblxuaDR7XG4gIGZvbnQtc2l6ZTogMTdweDtcbiAgY29sb3I6ICMwMDAwMDA7XG5cbn1cbmg1e1xuICBmb250LXNpemU6IDE1cHg7XG4gIGNvbG9yOiAjMDAwMDAwO1xufVxuLmhlYWRpbmd7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzZWI2YWM7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDE1MHB4O1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1NXB4O1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czo1NXB4IDtcblxuICAuaGVhZGluZ3tcbiAgICB3aWR0aDogMTAwJTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgICBoZWlnaHQ6IDUwcHg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBwYWRkaW5nLXRvcDogNDBweDtcbiAgICBpb24tbGFiZWx7XG5cbiAgICAgIGZvbnQtc2l6ZTogNTBweDtcbiAgICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAgICAgY29sb3I6ICNmZmZmZmY7XG4gICAgICBmb250LXdlaWdodDogYm9sZDtcbiAgICAgIHNwYW57XG4gICAgICAgIGNvbG9yOiAjMDAwMDAwO1xuICAgICAgfVxuICAgICAgXG4gICAgfVxuICAgIFxuICAgIH1cblxuICAgIGlucHV0e1xuICAgICAgYm9yZGVyOiBub25lO1xuICAgICAgbWFyZ2luLXRvcDogNTBweDtcbiAgICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xuICAgICAgd2lkdGg6IDkwJTtcbiAgICAgIGhlaWdodDogNTBweDtcbiAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XG4gICAgICBwYWRkaW5nLWxlZnQ6IDIwcHg7XG4gICAgfVxuICAgIHB7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgICBhe1xuICAgICAgICBjb2xvcjogIzAwMDAwMDtcbiAgICAgICAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XG4gICAgICAgIHBhZGRpbmctbGVmdDogMTVweDtcblxuICAgICAgfVxuICAgIH1cblxuICAgIGlvbi1pdGVte1xuICAgICAgLS1iYWNrZ3JvdW5kOiAjMDBjYWI5O1xuICAgICAgY29sb3I6ICNmN2Q5ZDk7XG4gICAgICAtLWJvcmRlci1zdHlsZTpub25lO1xuICAgICAgaW9uLWljb257XG4gICAgICAgIGZvbnQtc2l6ZTogMjBweDtcblxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC50cmF2ZWx7XG4gICAgd2lkdGg6IDEwMCU7XG4gICAgaGVpZ2h0OiAxMjBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xuICAgIG1hcmdpbi10b3A6IDIwcHg7XG4gICAgZGlzcGxheTogZmxleDtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWFyb3VuZDtcbiAgICBjb2x1bW4tZ2FwOiAyMHB4O1xuXG4gICAgLnRyYXZlbF9uYW1lc3tcbiAgICAgIGltZ3tcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogMjVweDtcbiAgICAgIH1cbiAgICAgIHB7XG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgICAgIG1hcmdpbi10b3A6IDBweDtcbiAgICAgICAgZm9udC1zaXplOiAxMnB4O1xuICAgICAgfVxuICAgIH1cbiAgICAuYWJvdXRDb250YWluZXIge1xuXG4gICAgICBtYXJnaW4tdG9wOiAtMXJlbTtcbiAgICAgIHBhZGRpbmc6IDFyZW07XG4gICAgXG4gICAgICBpb24tY2FyZC10aXRsZSB7XG4gICAgXG4gICAgICAgIGZvbnQtc2l6ZTogMS4ycmVtO1xuICAgICAgICBtYXJnaW4tYm90dG9tOiAwLjVyZW07XG4gICAgICB9XG4gICAgfVxuXG4gICAgLmxhYntcblxuICAgICAgY29sb3I6ICMwMGNhYjk7XG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cbiAgLmltZ3tcbiAgICAgICAgd2lkdGg6IDEwMCU7XG4gICAgICAgIGhlaWdodDogMjVweDtcbiAgICAgIH1cbn1cbmlvbi1yb3cge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIH1cblxuaW9uLWNvbHtcbiAgdGV4dC1hbGlnbjpjZW50ZXI7XG4gIHBhZGRpbmc6IDRweDtcbiAgaW9uLWljb257XG4gICAgICB6b29tOjM7XG4gICAgICBwYWRkaW5nOjEwcHg7XG4gICAgICAmOmZpcnN0LWNoaWxke1xuICAgICAgICAgIHpvb206Mi44O1xuICAgICAgICAgIHBhZGRpbmc6MnB4O1xuICAgICAgfVxuICB9XG4gIGg2e1xuICAgIGZvbnQtc2l6ZTogMTVweDtcbiAgICBjb2xvcjogIzAwMDAwMDtcbiAgfVxuICBpb24tY2FyZHtcbiAgICAgIHRleHQtYWxpZ246Y2VudGVyO1xuICAgICAgd2lkdGg6IDEyMHB4O1xuICAgICAgaGVpZ2h0OiAxMjBweDtcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICNlNDc1NzU7XG4gIH1cbiAgXG4gXG5cbn1cblxufVxuaW9uLWNvbnRlbnQge1xuICB3aWR0aDogY2FsYygxMDAlICsgMzVweCk7XG59XG5pb24tY29udGVudDo6cGFydChzY3JvbGwpIHtcbiAgcGFkZGluZy1yaWdodDogMTVweDtcbn1cblxuLm15Q29sb3Ige1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBibHVlO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBjb2xvcjogd2hpdGU7XG59XG5cbmgxe1xuICBmb250LXNpemU6IGxhcmdlO1xufVxuIl19 */";

/***/ }),

/***/ 3853:
/*!************************************************!*\
  !*** ./src/app/home/home.page.html?ngResource ***!
  \************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <div class=\"heading\">\n    <div class=\"heading\">\n      <div>\n        <ion-buttons slot=\"start\">\n          <ion-menu-button menuId=\"main-menu\" mode=\"ios\" defaultHref=\"/home1\" color=\"dark\"></ion-menu-button>\n          <ion-label><br>Trav<span>elsy</span></ion-label>\n          \n        </ion-buttons>\n      </div>\n    </div>\n  </div>\n<br>\n     \n \n    <ion-title class=\"ion-text-center\" style=\"background-color: #354d72\" >POPULAR DESTINATION</ion-title>\n  \n    <ion-grid>\n      <ion-row>\n        <ion-slides [options]=\"option\">\n\n          <ion-slide   *ngFor=\"let post of posts\">\n            <ion-card [routerLink]=\"['/place', post.id]\">  \n              <img class=\"img\" [src]=\"post.image\"/>\n            <div  class=\"card-title\">\n              <p>{{post.title}}<br>\n              {{post.Location}}<br>\n              {{post.price | currency:'RM'}}<br>\n              {{post.Rating}}\n              </p>\n            </div>\n          </ion-card>\n          </ion-slide>\n          \n        </ion-slides>\n        \n        <ion-col  size=\"6\">\n          <ion-card [routerLink]=\"['/accomodation']\" class=\"title\">\n            <img  src=\"assets/cutlery.gif\"width=\"120px\">\n            \n          </ion-card>\n          <ion-text>\n            <h6>RESTAURANT</h6>\n          </ion-text>\n        </ion-col>\n  \n        <ion-col size=\"6\">\n          <ion-card style=\"background-color:#0c0c0a;color: white;\" class=\"title\">\n            <img src=\"assets/building.gif\"width=\"120px\">\n            \n          </ion-card>\n          <ion-text>\n            <h6>ACCOMODATION</h6>\n          </ion-text>\n        </ion-col>\n        </ion-row>\n      </ion-grid>\n\n  </ion-content>\n\n  <ion-footer >\n    <ion-toolbar >\n      <ion-tabs >\n        <ion-tab-bar slot=\"bottom\">\n      \n          <ion-tab-button  tab=\"gallery\">\n            <ion-icon name=\"nuclear\"></ion-icon>\n            <ion-label>Gallery</ion-label>\n          </ion-tab-button>\n      \n          <ion-tab-button  tab=\"about\">\n            <ion-icon name=\"logo-tux\"></ion-icon>\n            <ion-label>Family</ion-label>\n          </ion-tab-button >\n\n        </ion-tab-bar>\n      </ion-tabs>\n    </ion-toolbar>\n  </ion-footer>";

/***/ })

}]);
//# sourceMappingURL=src_app_home_home_module_ts.js.map